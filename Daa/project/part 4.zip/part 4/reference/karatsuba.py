"""Integer multiplication by divide and conquer (Karatsuba), compared with the grade-school method.

Usage:
    python3 karatsuba.py <input_file>            multiply the two numbers with Karatsuba
    python3 karatsuba.py <input_file> --check    also run grade-school multiplication (slow for big inputs)

Input file format: line 1 is the number of digits n, line 2 is the first number, line 3 is the second.

The numbers are split in base 2 with shifts, so splitting and recombining cost O(n), exactly
as in the decimal version in the textbook. Recurrence: M(n) = 3 M(n/2) + O(n), so M(n) is in
Theta(n^log2(3)) = Theta(n^1.585), against Theta(n^2) for grade school.
"""
import sys, time
sys.setrecursionlimit(10000)
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)               # allow very long decimal strings

BASE_BITS = 64                                  # at or below this size, multiply directly (one machine step)

def karatsuba(x, y, stats):
    """x * y for non-negative integers. stats['base'] counts base-case multiplications."""
    if x.bit_length() <= BASE_BITS or y.bit_length() <= BASE_BITS:
        stats["base"] += 1
        return x * y
    m = max(x.bit_length(), y.bit_length()) // 2
    mask = (1 << m) - 1
    a, b = x >> m, x & mask                     # x = a * 2^m + b
    c, d = y >> m, y & mask                     # y = c * 2^m + d
    ac = karatsuba(a, c, stats)
    bd = karatsuba(b, d, stats)
    mid = karatsuba(a + b, c + d, stats) - ac - bd      # = ad + bc, with only 3 recursive calls
    return (ac << (2 * m)) + (mid << m) + bd

def grade_school(x_str, y_str):
    """Digit by digit multiplication, n*n single-digit products. Returns (product, digit_mults)."""
    a = [int(ch) for ch in reversed(x_str)]
    b = [int(ch) for ch in reversed(y_str)]
    res = [0] * (len(a) + len(b))
    for i, da in enumerate(a):
        carry = 0
        for j, db in enumerate(b):
            cur = res[i + j] + da * db + carry
            res[i + j] = cur % 10
            carry = cur // 10
        res[i + len(b)] += carry
    s = "".join(map(str, reversed(res))).lstrip("0")
    return int(s or "0"), len(a) * len(b)

def read_numbers(path):
    with open(path) as f:
        n = int(f.readline())
        xs, ys = f.readline().strip(), f.readline().strip()
    assert len(xs) == n and len(ys) == n
    return n, xs, ys

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    n, xs, ys = read_numbers(sys.argv[1])
    x, y = int(xs), int(ys)
    stats = {"base": 0}
    t = time.perf_counter()
    p = karatsuba(x, y, stats)
    t_k = time.perf_counter() - t
    assert p == x * y, "Karatsuba result is wrong"
    s = str(p)
    print(f"n = {n} digits")
    print(f"Product has {len(s)} digits: {s[:20]}...{s[-20:]}")
    print(f"Karatsuba: time = {t_k:.4f} s, base-case multiplications = {stats['base']}")
    if "--check" in sys.argv:
        t = time.perf_counter()
        q, mults = grade_school(xs, ys)
        t_g = time.perf_counter() - t
        assert q == p
        print(f"Grade school: time = {t_g:.4f} s, single-digit multiplications = {mults}")
        print("Products match.")

if __name__ == "__main__":
    main()
