"""Closest pair of points in the plane, divide and conquer, O(n log n).

Usage:
    python3 closest_pair.py <input_file>            run the divide and conquer algorithm
    python3 closest_pair.py <input_file> --check    also run the O(n^2) brute force and compare

Input file format: first line is n, then n lines of "x y" (integers).
"""
import sys, time
from math import sqrt, inf

def read_points(path):
    with open(path) as f:
        n = int(f.readline())
        pts = [tuple(map(int, f.readline().split())) for _ in range(n)]
    assert len(pts) == n
    return pts

def d2(p, q):
    return (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2

def brute_force(pts):
    best, pair = inf, None
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            d = d2(pts[i], pts[j])
            if d < best:
                best, pair = d, (pts[i], pts[j])
    return best, pair

def closest_pair(pts):
    """Return (squared distance, (p, q)). Points are sorted by x once and by y once;
    the y order is split along with the x order so no level has to re-sort."""
    px = sorted(range(len(pts)), key=lambda i: pts[i])             # indices sorted by x (then y)
    py = sorted(range(len(pts)), key=lambda i: (pts[i][1], pts[i][0]))
    return _rec(pts, px, py)

def _rec(pts, px, py):
    n = len(px)
    if n <= 3:                                                     # base case: brute force
        best, pair = inf, None
        for a in range(n):
            for b in range(a + 1, n):
                d = d2(pts[px[a]], pts[px[b]])
                if d < best:
                    best, pair = d, (pts[px[a]], pts[px[b]])
        return best, pair
    mid = n // 2
    mid_x = pts[px[mid]][0]                                        # dividing vertical line
    left_x, right_x = px[:mid], px[mid:]
    left_set = set(left_x)
    left_y = [i for i in py if i in left_set]                      # y order of each half
    right_y = [i for i in py if i not in left_set]
    dl, pl = _rec(pts, left_x, left_y)
    dr, pr = _rec(pts, right_x, right_y)
    best, pair = (dl, pl) if dl <= dr else (dr, pr)
    strip = [i for i in py if (pts[i][0] - mid_x) ** 2 < best]     # points within sqrt(best) of the line
    for a in range(len(strip)):
        p = pts[strip[a]]
        for b in range(a + 1, len(strip)):
            q = pts[strip[b]]
            if (q[1] - p[1]) ** 2 >= best:                         # at most ~7 neighbours pass this test
                break
            d = d2(p, q)
            if d < best:
                best, pair = d, (p, q)
    return best, pair

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    pts = read_points(sys.argv[1])
    t = time.perf_counter()
    best, pair = closest_pair(pts)
    t_dc = time.perf_counter() - t
    print(f"n = {len(pts)}")
    print(f"Divide and conquer: {pair[0]} and {pair[1]}, distance = {sqrt(best):.4f}, time = {t_dc:.4f} s")
    if "--check" in sys.argv:
        t = time.perf_counter()
        bb, bp = brute_force(pts)
        t_bf = time.perf_counter() - t
        print(f"Brute force       : {bp[0]} and {bp[1]}, distance = {sqrt(bb):.4f}, time = {t_bf:.4f} s")
        assert bb == best, "distances differ"
        print("Distances match.")

if __name__ == "__main__":
    main()
