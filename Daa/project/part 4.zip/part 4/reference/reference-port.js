// Verified JavaScript port of both algorithms plus a check against expected.json.
// Use it as the starting point for app/js/closest-pair.js and app/js/karatsuba.js. Run: node reference/reference-port.js
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const exp = JSON.parse(fs.readFileSync(root + '/reference/expected.json'));
function d2(p, q) { return (p[0]-q[0])**2 + (p[1]-q[1])**2; }
function closest(pts) {
  const idx = pts.map((_, i) => i);
  const px = [...idx].sort((a,b) => pts[a][0]-pts[b][0] || pts[a][1]-pts[b][1] || a-b);
  const py = [...idx].sort((a,b) => pts[a][1]-pts[b][1] || pts[a][0]-pts[b][0] || a-b);
  function rec(px, py) {
    const n = px.length;
    if (n <= 3) { let best = Infinity, pair = null;
      for (let a=0;a<n;a++) for (let b=a+1;b<n;b++){ const d=d2(pts[px[a]],pts[px[b]]); if(d<best){best=d;pair=[pts[px[a]],pts[px[b]]];} }
      return [best, pair]; }
    const mid = n>>1, midX = pts[px[mid]][0];
    const L = px.slice(0, mid), R = px.slice(mid), ls = new Set(L);
    const ly = py.filter(i => ls.has(i)), ry = py.filter(i => !ls.has(i));
    const a = rec(L, ly), b = rec(R, ry);
    let [best, pair] = a[0] <= b[0] ? a : b;
    const strip = py.filter(i => (pts[i][0]-midX)**2 < best);
    for (let i=0;i<strip.length;i++) for (let j=i+1;j<strip.length;j++){
      const p=pts[strip[i]], q=pts[strip[j]];
      if ((q[1]-p[1])**2 >= best) break;
      const d=d2(p,q); if (d<best){best=d;pair=[p,q];}
    }
    return [best, pair];
  }
  return rec(px, py);
}
const bl = x => x === 0n ? 0 : x.toString(2).length;
function kara(x, y, st) {
  if (bl(x) <= 64 || bl(y) <= 64) { st.base++; return x*y; }
  const m = BigInt(Math.floor(Math.max(bl(x), bl(y))/2)), mask = (1n<<m)-1n;
  const a = x>>m, b = x&mask, c = y>>m, d = y&mask;
  const ac = kara(a,c,st), bd = kara(b,d,st), mid = kara(a+b,c+d,st)-ac-bd;
  return (ac << (2n*m)) + (mid << m) + bd;
}
let ok = 0, bad = 0;
for (const [f, e] of Object.entries(exp.closest_pair)) {
  const lines = fs.readFileSync(root+'/sample_data/closest_pair/'+f,'utf8').split(/\r?\n/);
  const n = +lines[0], pts = lines.slice(1,1+n).map(l => l.trim().split(/\s+/).map(Number));
  const t = Date.now(); const [best] = closest(pts);
  const pass = best === e.squared_distance; pass ? ok++ : bad++;
  console.log(pass?'PASS':'FAIL', f, best, Date.now()-t, 'ms');
}
for (const [f, e] of Object.entries(exp.integer_multiplication)) {
  const lines = fs.readFileSync(root+'/sample_data/integer_multiplication/'+f,'utf8').split(/\r?\n/);
  const x = BigInt(lines[1].trim()), y = BigInt(lines[2].trim()), st = {base:0};
  const t = Date.now(); const p = kara(x,y,st);
  const pass = st.base === e.base_case_multiplications && p === x*y; pass ? ok++ : bad++;
  console.log(pass?'PASS':'FAIL', f, st.base, Date.now()-t, 'ms');
}
console.log(ok, 'passed,', bad, 'failed');
