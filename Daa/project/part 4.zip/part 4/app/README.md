# Divide and Conquer Visualizer

A responsive, offline web application that visualizes two divide and conquer algorithms:
1. Closest Pair of Points in the plane: O(n log n) divide and conquer algorithm using squared distances.
2. Karatsuba Integer Multiplication: O(n^1.585) integer multiplication using 64-bit base cases and binary bit shifts.

## Deliverables and Technical Rules
- Pure HTML5, CSS3, and modern vanilla JavaScript. No external dependencies, CDNs, frameworks, or build steps.
- Works 100% offline via file:// protocol by double-clicking `app/index.html`.
- Dual runtime support: all logic modules in `app/js/` run in both desktop/mobile browsers and Node.js via the shared `DAA` global namespace.
- Mobile-first responsive interface that scales gracefully from 360 px smartphones to large 4K displays with touch targets of at least 44 px.

## Quick Start: How to Open the App
1. In your file explorer, navigate to the `app/` folder.
2. Double-click `index.html` to open it in Google Chrome, Microsoft Edge, or Mozilla Firefox.
3. No web server or internet connection is required.

## Using the Application
1. **Load a Dataset**: Click the **Choose file** button or drag and drop any file from the `sample_data/` directory.
   - Files with two space-separated integers on line 2 are auto-detected as **Closest Pair**.
   - Files with single long digit strings on lines 2 and 3 are auto-detected as **Integer Multiplication**.
   - If desired, click **Switch Type** on the file card to manually override the detected problem type.
2. **Interactive Playback**:
   - **Play / Pause**: Starts or pauses automated step-by-step playback (Keyboard shortcut: **Space**).
   - **Step Forward (&rarr;)**: Advances execution by 1 event (Keyboard shortcut: **Right Arrow**).
   - **Step Back (&larr;)**: Rewinds execution by 1 event using pre-calculated 200-event checkpoints (Keyboard shortcut: **Left Arrow**).
   - **Reset**: Returns visualizer and counters to step 0.
   - **Jump to End (&rarr;|)**: Instantly jumps to the final state and renders the complete solution.
   - **Speed Slider**: Adjusts animation playback from 1x (relaxed pacing) up to 10x (burst playback).
   - **Animate Depth Up To Slider**: Controls how deep into recursion fine-grained step events are recorded. Subproblems deeper than this threshold run silently in O(n log n) and collapse into a single summary event, keeping even 15,000-point files fast and responsive.
3. **Visualization Features**:
   - **Closest Pair**:
     - Scaled 2D canvas rendered with high-DPI `devicePixelRatio`.
     - Vertical dividing lines color-coded by recursion depth (8-color palette).
     - Subproblem region shading and yellow strip inspection bands.
     - Candidate comparison vectors drawn between points.
     - Concentric green rings highlighting current and final closest pairs.
     - **Zoom to answer**: Centers and magnifies the closest pair within its local neighborhood.
   - **Karatsuba Integer Multiplication**:
     - Shortened preview card displaying operand lengths in decimal digits and binary bits.
     - Interactive 4-tier SVG recursion tree (depths 0 to 3, up to 40 nodes) showing `a*c`, `b*d`, and `(a+b)*(c+d)` branches.
     - Nodes at depth 3 feature "+N mults" badges indicating deeper sub-multiplications below.
     - Active traversal node highlights following depth-first call order.
     - **Interactive Working Panel**: Click or tap any tree node to inspect its mathematical splitting equations, bit shift parameters, subproducts, and recombine formulas.
     - Recursion level table and comparative bar chart comparing Karatsuba against O(n^2) grade-school multiplication.
4. **Brute Force Verification**:
   - The result card includes a **Run brute force check** button.
   - Runs O(n^2) all-pairs check for closest pair (up to 5,000 points) or O(n^2) grade-school multiplication (up to 4,096 digits).
   - Reports execution time and confirms that answers match divide and conquer outputs.

## Running the Automated Test Suite
To verify both algorithms across all 20 benchmark datasets in `sample_data/`:
```bash
node app/tests/run-tests.js
```
The test suite checks:
1. Plain Closest Pair squared distance matching `reference/expected.json` (10 files).
2. Closest Pair Event Recorder squared distance matching `reference/expected.json` (10 files).
3. Plain Karatsuba base-case count and native BigInt product equality (10 files).
4. Karatsuba Tree Recorder base-case count and native BigInt product equality (10 files).
Total: 40 tests (all 40 must pass).

