// run-tests.js: Node test runner for all 20 sample files plus event & tree recorder verification
const fs = require('fs');
const path = require('path');

// Determine project root directory (task4-ui)
let task4Root = path.resolve(__dirname, '..', '..');
if (!fs.existsSync(path.join(task4Root, 'reference', 'expected.json'))) {
  if (fs.existsSync(path.join(task4Root, 'task4-ui', 'reference', 'expected.json'))) {
    task4Root = path.join(task4Root, 'task4-ui');
  }
}

// Load modules
const parserPath = path.join(task4Root, 'app', 'js', 'parser.js');
const closestPath = path.join(task4Root, 'app', 'js', 'closest-pair.js');
const karatsubaPath = path.join(task4Root, 'app', 'js', 'karatsuba.js');

const DAA = require(parserPath);
require(closestPath);
require(karatsubaPath);

const expectedPath = path.join(task4Root, 'reference', 'expected.json');
const expected = JSON.parse(fs.readFileSync(expectedPath, 'utf8'));

let passed = 0;
let failed = 0;

console.log('Testing Closest Pair of Points (Plain Algorithm - 10 files):');
for (const [filename, expData] of Object.entries(expected.closest_pair)) {
  const filePath = path.join(task4Root, 'sample_data', 'closest_pair', filename);
  const rawText = fs.readFileSync(filePath, 'utf8');

  const start = Date.now();
  const parsed = DAA.parseInput(rawText);
  const result = DAA.closestPair(parsed.points);
  const elapsed = Date.now() - start;

  const distMatch = result.squaredDistance === expData.squared_distance;
  const countMatch = parsed.n === expData.n;

  if (distMatch && countMatch) {
    passed++;
    console.log(`PASS ${filename} dist=${result.squaredDistance} (${elapsed} ms)`);
  } else {
    failed++;
    console.log(`FAIL ${filename} expected=${expData.squared_distance} got=${result.squaredDistance}`);
  }
}

console.log('\nTesting Closest Pair Event Recorder (closestPairWithEvents - 10 files):');
for (const [filename, expData] of Object.entries(expected.closest_pair)) {
  const filePath = path.join(task4Root, 'sample_data', 'closest_pair', filename);
  const rawText = fs.readFileSync(filePath, 'utf8');

  const start = Date.now();
  const parsed = DAA.parseInput(rawText);
  const animRes = DAA.closestPairWithEvents(parsed.points, 4);
  const elapsed = Date.now() - start;

  const distMatch = animRes.squaredDistance === expData.squared_distance;
  const hasEvents = animRes.events && animRes.events.length > 0;

  if (distMatch && hasEvents) {
    passed++;
    console.log(`PASS ${filename} (withEvents) dist=${animRes.squaredDistance} events=${animRes.events.length} (${elapsed} ms)`);
  } else {
    failed++;
    console.log(`FAIL ${filename} (withEvents) expected=${expData.squared_distance} got=${animRes.squaredDistance} hasEvents=${hasEvents}`);
  }
}

console.log('\nTesting Karatsuba Integer Multiplication (Plain Algorithm - 10 files):');
for (const [filename, expData] of Object.entries(expected.integer_multiplication)) {
  const filePath = path.join(task4Root, 'sample_data', 'integer_multiplication', filename);
  const rawText = fs.readFileSync(filePath, 'utf8');

  const start = Date.now();
  const parsed = DAA.parseInput(rawText);
  const result = DAA.karatsuba(parsed.x, parsed.y);
  const elapsed = Date.now() - start;

  const baseCasesMatch = result.baseCases === expData.base_case_multiplications;
  const productMatch = result.product === (parsed.x * parsed.y);

  if (baseCasesMatch && productMatch) {
    passed++;
    console.log(`PASS ${filename} baseCases=${result.baseCases} (${elapsed} ms)`);
  } else {
    failed++;
    console.log(`FAIL ${filename} expectedBaseCases=${expData.base_case_multiplications} got=${result.baseCases} prodMatch=${productMatch}`);
  }
}

console.log('\nTesting Karatsuba Tree Recorder (karatsubaWithTree - 10 files):');
for (const [filename, expData] of Object.entries(expected.integer_multiplication)) {
  const filePath = path.join(task4Root, 'sample_data', 'integer_multiplication', filename);
  const rawText = fs.readFileSync(filePath, 'utf8');

  const start = Date.now();
  const parsed = DAA.parseInput(rawText);
  const treeRes = DAA.karatsubaWithTree(parsed.x, parsed.y, 4);
  const elapsed = Date.now() - start;

  const baseCasesMatch = treeRes.baseCases === expData.base_case_multiplications;
  const productMatch = treeRes.product === (parsed.x * parsed.y);
  const hasTree = !!treeRes.tree;
  const hasStats = treeRes.depthStats && treeRes.depthStats.length > 0;
  const hasEvents = treeRes.events && treeRes.events.length > 0;

  if (baseCasesMatch && productMatch && hasTree && hasStats && hasEvents) {
    passed++;
    console.log(`PASS ${filename} (withTree) baseCases=${treeRes.baseCases} events=${treeRes.events.length} depthLevels=${treeRes.depthStats.length} (${elapsed} ms)`);
  } else {
    failed++;
    console.log(`FAIL ${filename} (withTree) expectedBaseCases=${expData.base_case_multiplications} got=${treeRes.baseCases} prodMatch=${productMatch}`);
  }
}

console.log(`\nSummary: ${passed} passed, ${failed} failed`);

if (failed > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
