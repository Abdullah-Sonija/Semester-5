// viz-karatsuba.js: Tree visualization, Working panel, and level table for Karatsuba
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  function formatShort(num, maxLen) {
    if (num === null || num === undefined) return '0';
    var s = num.toString();
    if (s.length <= maxLen) return s;
    var half = Math.floor((maxLen - 3) / 2);
    return s.slice(0, half) + '...' + s.slice(-half) + ' (' + s.length + ' digits)';
  }

  function KaratsubaVisualizer(containerElement) {
    this.container = containerElement;
    this.treeData = null;
    this.activeNodeId = null;
    this.selectedNode = null;
    this.depthStats = [];
    this.totalBaseCases = 0;
    this.nodeMap = {};
  }

  KaratsubaVisualizer.prototype.setData = function (animData) {
    this.animData = animData;
    this.treeData = animData.tree;
    this.depthStats = animData.depthStats || [];
    this.totalBaseCases = animData.baseCases || 0;
    this.activeNodeId = null;
    this.selectedNode = animData.tree;
    this.nodeMap = {};

    this.indexNodes(this.treeData);
    this.render();
  };

  KaratsubaVisualizer.prototype.indexNodes = function (node) {
    if (!node) return;
    this.nodeMap[node.id] = node;
    if (node.children) {
      for (var i = 0; i < node.children.length; i++) {
        this.indexNodes(node.children[i]);
      }
    }
  };

  KaratsubaVisualizer.prototype.setActiveNode = function (nodeId) {
    this.activeNodeId = nodeId;
    var node = this.nodeMap[nodeId];
    if (node) {
      this.selectedNode = node;
    }
    this.updateHighlights();
    this.updateWorkingPanel();
  };

  KaratsubaVisualizer.prototype.render = function () {
    if (!this.container || !this.animData) return;

    this.container.innerHTML = '';

    // 1. Number Preview Card
    var numCard = document.createElement('div');
    numCard.className = 'kt-numbers-card';
    var x = this.animData.x;
    var y = this.animData.y;
    var xStr = x.toString();
    var yStr = y.toString();
    var xShort = xStr.length <= 26 ? xStr : xStr.slice(0, 12) + '...' + xStr.slice(-12);
    var yShort = yStr.length <= 26 ? yStr : yStr.slice(0, 12) + '...' + yStr.slice(-12);

    numCard.innerHTML =
      '<div class="kt-num-row">' +
        '<span class="kt-num-name">X:</span> ' +
        '<span class="kt-num-val" title="' + xStr.slice(0, 50) + '...">' + xShort + '</span> ' +
        '<span class="kt-num-meta">(' + xStr.length.toLocaleString() + ' digits, ' + DAA.bitLength(x) + ' bits)</span>' +
      '</div>' +
      '<div class="kt-num-row">' +
        '<span class="kt-num-name">Y:</span> ' +
        '<span class="kt-num-val" title="' + yStr.slice(0, 50) + '...">' + yShort + '</span> ' +
        '<span class="kt-num-meta">(' + yStr.length.toLocaleString() + ' digits, ' + DAA.bitLength(y) + ' bits)</span>' +
      '</div>';
    this.container.appendChild(numCard);

    // 2. SVG Tree Card (depths 0 to 3)
    var treeWrapper = document.createElement('div');
    treeWrapper.className = 'kt-tree-wrapper scrollable-box';
    this.treeSvg = this.buildSvgTree();
    treeWrapper.appendChild(this.treeSvg);
    this.container.appendChild(treeWrapper);

    // 3. Working Panel for selected node
    this.workingPanel = document.createElement('div');
    this.workingPanel.className = 'kt-working-panel';
    this.container.appendChild(this.workingPanel);
    this.updateWorkingPanel();

    // 4. Level Table and Comparison Bar Card
    var statsCard = document.createElement('div');
    statsCard.className = 'kt-stats-card';
    statsCard.innerHTML = this.buildStatsHtml();
    this.container.appendChild(statsCard);
  };

  KaratsubaVisualizer.prototype.buildSvgTree = function () {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    var svgWidth = 2200;
    var svgHeight = 440;
    svg.setAttribute('width', svgWidth);
    svg.setAttribute('height', svgHeight);
    svg.setAttribute('viewBox', '0 0 ' + svgWidth + ' ' + svgHeight);
    svg.setAttribute('class', 'kt-tree-svg');

    var self = this;
    var nodePositions = {};

    // Compute positions for 4 tiers (depths 0 to 3)
    function layoutNode(node, d, left, right) {
      if (!node || d > 3) return;
      var x = (left + right) / 2;
      var y = 50 + d * 105;
      nodePositions[node.id] = { x: x, y: y, node: node };

      if (node.children && node.children.length === 3 && d < 3) {
        var chunk = (right - left) / 3;
        layoutNode(node.children[0], d + 1, left, left + chunk);
        layoutNode(node.children[1], d + 1, left + chunk, left + 2 * chunk);
        layoutNode(node.children[2], d + 1, left + 2 * chunk, right);
      }
    }

    layoutNode(this.treeData, 0, 0, svgWidth);

    // 1. Draw connecting branches (paths)
    var gLinks = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    gLinks.setAttribute('class', 'kt-links');

    Object.keys(nodePositions).forEach(function (id) {
      var item = nodePositions[id];
      var node = item.node;
      if (node.children && node.depth < 3) {
        for (var c = 0; c < node.children.length; c++) {
          var ch = node.children[c];
          var chPos = nodePositions[ch.id];
          if (chPos) {
            var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            var dStr = 'M ' + item.x + ' ' + (item.y + 24) +
                       ' C ' + item.x + ' ' + (item.y + 60) +
                       ', ' + chPos.x + ' ' + (chPos.y - 40) +
                       ', ' + chPos.x + ' ' + (chPos.y - 20);
            path.setAttribute('d', dStr);
            path.setAttribute('class', 'kt-branch-path');
            gLinks.appendChild(path);
          }
        }
      }
    });
    svg.appendChild(gLinks);

    // 2. Draw Nodes
    var gNodes = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    gNodes.setAttribute('class', 'kt-nodes');

    Object.keys(nodePositions).forEach(function (id) {
      var item = nodePositions[id];
      var node = item.node;

      var gNode = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      gNode.setAttribute('class', 'kt-node-group' + (node.id === self.activeNodeId ? ' active' : ''));
      gNode.setAttribute('id', 'kt-node-' + node.id);
      gNode.setAttribute('transform', 'translate(' + item.x + ',' + item.y + ')');
      gNode.style.cursor = 'pointer';

      // Node background box
      var rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      var nw = 68;
      var nh = 42;
      rect.setAttribute('x', -nw / 2);
      rect.setAttribute('y', -nh / 2);
      rect.setAttribute('width', nw);
      rect.setAttribute('height', nh);
      rect.setAttribute('rx', 6);
      rect.setAttribute('class', 'kt-node-rect');
      gNode.appendChild(rect);

      // Role text (e.g. a*c)
      var textRole = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      textRole.setAttribute('y', -4);
      textRole.setAttribute('text-anchor', 'middle');
      textRole.setAttribute('class', 'kt-node-role');
      textRole.textContent = node.roleLabel;
      gNode.appendChild(textRole);

      // Bits text
      var textBits = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      textBits.setAttribute('y', 12);
      textBits.setAttribute('text-anchor', 'middle');
      textBits.setAttribute('class', 'kt-node-bits');
      textBits.textContent = Math.max(node.uBits, node.vBits) + ' bits';
      gNode.appendChild(textBits);

      // If at depth 3, add deeper calls badge below
      if (node.depth === 3 && node.subBaseCases > 1) {
        var badgeGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        badgeGroup.setAttribute('transform', 'translate(0, 32)');

        var badgeRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        badgeRect.setAttribute('x', -34);
        badgeRect.setAttribute('y', -8);
        badgeRect.setAttribute('width', 68);
        badgeRect.setAttribute('height', 16);
        badgeRect.setAttribute('rx', 4);
        badgeRect.setAttribute('class', 'kt-deeper-badge');
        badgeGroup.appendChild(badgeRect);

        var badgeText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        badgeText.setAttribute('y', 4);
        badgeText.setAttribute('text-anchor', 'middle');
        badgeText.setAttribute('class', 'kt-deeper-text');
        badgeText.textContent = '+' + node.subBaseCases + ' mults';
        badgeGroup.appendChild(badgeText);

        gNode.appendChild(badgeGroup);
      }

      gNode.addEventListener('click', function () {
        self.selectedNode = node;
        self.updateHighlights();
        self.updateWorkingPanel();
      });

      gNodes.appendChild(gNode);
    });

    svg.appendChild(gNodes);
    return svg;
  };

  KaratsubaVisualizer.prototype.updateHighlights = function () {
    if (!this.container) return;
    var self = this;
    var allNodeGroups = this.container.querySelectorAll('.kt-node-group');
    allNodeGroups.forEach(function (el) {
      el.classList.remove('active');
      el.classList.remove('selected');
    });

    if (this.activeNodeId) {
      var actEl = document.getElementById('kt-node-' + this.activeNodeId);
      if (actEl) actEl.classList.add('active');
    }

    if (this.selectedNode) {
      var selEl = document.getElementById('kt-node-' + this.selectedNode.id);
      if (selEl) selEl.classList.add('selected');
    }
  };

  KaratsubaVisualizer.prototype.updateWorkingPanel = function () {
    if (!this.workingPanel) return;
    var node = this.selectedNode;
    if (!node) {
      this.workingPanel.innerHTML = '<p class="text-muted">Click any tree node to inspect its equations.</p>';
      return;
    }

    var html =
      '<div class="card-header">' +
        '<h3 class="card-title">Working Panel: Node ' + node.roleLabel + ' (Depth ' + node.depth + ')</h3>' +
        '<span class="badge">' + Math.max(node.uBits, node.vBits) + ' bits</span>' +
      '</div>';

    if (node.isBase) {
      html +=
        '<div class="kt-working-body">' +
          '<p><strong>Base Case (<= 64 bits):</strong> Operands are small enough to multiply in a single hardware machine step.</p>' +
          '<div class="kt-math-box">' +
            '<code>u = ' + node.u + '</code><br>' +
            '<code>v = ' + node.v + '</code><br>' +
            '<code>Product = u * v = ' + node.result + '</code>' +
          '</div>' +
        '</div>';
    } else {
      var m = node.m.toString();
      html +=
        '<div class="kt-working-body">' +
          '<p class="kt-note">Operands are split at binary half <code>m = ' + m + ' bits</code> using binary bit shifts. ' +
          'Because shifting and masking an n-bit integer in memory runs in O(n) linear time, splitting costs only O(n).</p>' +

          '<div class="kt-split-equations">' +
            '<div class="kt-eq-row"><strong>Formula:</strong> <code>x = a &middot; 2<sup>m</sup> + b</code> and <code>y = c &middot; 2<sup>m</sup> + d</code></div>' +
            '<div class="kt-math-box">' +
              '<div><strong>a</strong> (x &gt;&gt; ' + m + '): <code>' + formatShort(node.a, 35) + '</code></div>' +
              '<div><strong>b</strong> (x &amp; mask): <code>' + formatShort(node.b, 35) + '</code></div>' +
              '<div><strong>c</strong> (y &gt;&gt; ' + m + '): <code>' + formatShort(node.c, 35) + '</code></div>' +
              '<div><strong>d</strong> (y &amp; mask): <code>' + formatShort(node.d, 35) + '</code></div>' +
            '</div>' +
          '</div>' +

          '<div class="kt-subproducts">' +
            '<p><strong>Subproducts (3 recursive calls):</strong></p>' +
            '<ul>' +
              '<li><code>ac = a &middot; c = ' + formatShort(node.ac, 30) + '</code></li>' +
              '<li><code>bd = b &middot; d = ' + formatShort(node.bd, 30) + '</code></li>' +
              '<li><code>mid = (a+b)(c+d) - ac - bd = ' + formatShort(node.midProduct, 30) + '</code></li>' +
            '</ul>' +
          '</div>' +

          '<div class="kt-combine-box">' +
            '<strong>Combine:</strong> <code>(ac &lt;&lt; 2m) + (mid &lt;&lt; m) + bd</code><br>' +
            '<strong>Result:</strong> <code>' + formatShort(node.result, 40) + '</code>' +
          '</div>' +
        '</div>';
    }

    this.workingPanel.innerHTML = html;
  };

  KaratsubaVisualizer.prototype.buildStatsHtml = function () {
    var digits = (this.animData && this.animData.x) ? this.animData.x.toString().length : 0;
    var gradeSchoolOps = digits * digits;
    var karaOps = this.totalBaseCases;
    var speedup = gradeSchoolOps > 0 ? (gradeSchoolOps / Math.max(karaOps, 1)).toFixed(1) : '1.0';

    var html =
      '<h3 class="card-title">Recursion Level Table & Comparison</h3>' +
      '<div class="kt-table-wrapper scrollable-box">' +
        '<table class="kt-level-table">' +
          '<thead>' +
            '<tr>' +
              '<th>Depth</th>' +
              '<th>Calls (3<sup>d</sup>)</th>' +
              '<th>Operand Size</th>' +
              '<th>Base Multiplications</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody>';

    for (var i = 0; i < this.depthStats.length; i++) {
      var st = this.depthStats[i];
      html +=
        '<tr>' +
          '<td>Depth ' + st.depth + '</td>' +
          '<td>' + st.calls.toLocaleString() + '</td>' +
          '<td>' + st.operandBits + ' bits</td>' +
          '<td>' + st.baseCases.toLocaleString() + '</td>' +
        '</tr>';
    }

    html +=
          '</tbody>' +
        '</table>' +
      '</div>' +

      '<div class="kt-comparison-bars">' +
        '<div class="kt-bar-row">' +
          '<div class="kt-bar-label"><span>Karatsuba base mults:</span> <strong>' + karaOps.toLocaleString() + '</strong></div>' +
          '<div class="kt-bar-track"><div class="kt-bar-fill kt-bar-kara" style="width: ' + Math.min(100, Math.max(5, (karaOps / Math.max(gradeSchoolOps, 1)) * 100)) + '%"></div></div>' +
        '</div>' +
        '<div class="kt-bar-row">' +
          '<div class="kt-bar-label"><span>Grade school digit mults (n&sup2;):</span> <strong>' + gradeSchoolOps.toLocaleString() + '</strong></div>' +
          '<div class="kt-bar-track"><div class="kt-bar-fill kt-bar-gs" style="width: 100%"></div></div>' +
        '</div>' +
        '<p class="kt-bar-summary">Karatsuba executes roughly <strong>' + speedup + 'x</strong> fewer multiplications than the O(n&sup2;) grade school method.</p>' +
      '</div>';

    return html;
  };

  DAA.KaratsubaVisualizer = KaratsubaVisualizer;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}

