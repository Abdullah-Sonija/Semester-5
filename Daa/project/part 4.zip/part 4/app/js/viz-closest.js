// viz-closest.js: Canvas visualization for closest pair of points
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  var DEPTH_COLORS = [
    '#ef4444', // red
    '#f97316', // orange
    '#eab308', // yellow
    '#10b981', // green
    '#06b6d4', // cyan
    '#3b82f6', // blue
    '#8b5cf6', // purple
    '#ec4899'  // pink
  ];

  function ClosestPairVisualizer(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement.getContext('2d');
    this.points = [];
    this.bounds = { minX: 0, maxX: 1000000, minY: 0, maxY: 1000000 };
    this.isZoomed = false;
    this.zoomBounds = null;
    this.activeLines = [];
    this.currentEvent = null;
    this.finalPair = null;
    this.finalDistance = null;

    this.setupResizeListener();
  }

  ClosestPairVisualizer.prototype.setupResizeListener = function () {
    var self = this;
    if (typeof window !== 'undefined') {
      window.addEventListener('resize', function () {
        self.resizeCanvas();
        self.render();
      });
    }
  };

  ClosestPairVisualizer.prototype.resizeCanvas = function () {
    if (!this.canvas) return;
    var rect = this.canvas.getBoundingClientRect();
    var dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;

    var cssWidth = Math.max(rect.width, 280);
    var cssHeight = Math.max(rect.height, 320);

    this.canvas.width = Math.floor(cssWidth * dpr);
    this.canvas.height = Math.floor(cssHeight * dpr);
    this.width = cssWidth;
    this.height = cssHeight;
    this.dpr = dpr;

    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  ClosestPairVisualizer.prototype.setPoints = function (pts) {
    this.points = pts || [];
    this.isZoomed = false;
    this.zoomBounds = null;
    this.activeLines = [];
    this.currentEvent = null;
    this.finalPair = null;
    this.finalDistance = null;

    if (this.points.length > 0) {
      var minX = Infinity;
      var maxX = -Infinity;
      var minY = Infinity;
      var maxY = -Infinity;

      for (var i = 0; i < this.points.length; i++) {
        var p = this.points[i];
        if (p[0] < minX) minX = p[0];
        if (p[0] > maxX) maxX = p[0];
        if (p[1] < minY) minY = p[1];
        if (p[1] > maxY) maxY = p[1];
      }

      this.bounds = { minX: minX, maxX: maxX, minY: minY, maxY: maxY };
    }

    this.resizeCanvas();
    this.render();
  };

  ClosestPairVisualizer.prototype.toScreenX = function (x, b, pad, scale, offX) {
    return offX + (x - b.minX) * scale;
  };

  ClosestPairVisualizer.prototype.toScreenY = function (y, b, pad, scale, offY) {
    return this.height - (offY + (y - b.minY) * scale);
  };

  ClosestPairVisualizer.prototype.getTransform = function () {
    var b = this.isZoomed && this.zoomBounds ? this.zoomBounds : this.bounds;
    var pad = this.isZoomed ? 40 : 24;

    var rangeX = (b.maxX - b.minX) || 1;
    var rangeY = (b.maxY - b.minY) || 1;

    var availW = Math.max(this.width - 2 * pad, 10);
    var availH = Math.max(this.height - 2 * pad, 10);

    var scale = Math.min(availW / rangeX, availH / rangeY);
    var offX = pad + (availW - rangeX * scale) / 2;
    var offY = pad + (availH - rangeY * scale) / 2;

    return { b: b, pad: pad, scale: scale, offX: offX, offY: offY };
  };

  ClosestPairVisualizer.prototype.toggleZoom = function () {
    if (!this.finalPair) return;
    this.isZoomed = !this.isZoomed;
    if (this.isZoomed) {
      var p1 = this.finalPair[0];
      var p2 = this.finalPair[1];
      var midX = (p1[0] + p2[0]) / 2;
      var midY = (p1[1] + p2[1]) / 2;
      var dx = Math.abs(p1[0] - p2[0]);
      var dy = Math.abs(p1[1] - p2[1]);
      var span = Math.max(dx, dy, 200) * 3;

      this.zoomBounds = {
        minX: midX - span,
        maxX: midX + span,
        minY: midY - span,
        maxY: midY + span
      };
    }
    this.render();
  };

  ClosestPairVisualizer.prototype.updateState = function (ev, activeLinesList, isEnd, finalPair, finalDist) {
    this.currentEvent = ev;
    this.activeLines = activeLinesList ? activeLinesList.slice() : [];
    if (isEnd) {
      this.finalPair = finalPair;
      this.finalDistance = finalDist;
    }
    this.render();
  };

  ClosestPairVisualizer.prototype.render = function () {
    var ctx = this.ctx;
    if (!ctx || !this.width || !this.height) return;

    ctx.clearRect(0, 0, this.width, this.height);

    if (this.points.length === 0) return;

    var t = this.getTransform();
    var b = t.b;
    var pad = t.pad;
    var scale = t.scale;
    var offX = t.offX;
    var offY = t.offY;

    var ev = this.currentEvent;

    // 1. Draw active subproblem region shading
    if (ev && ev.region) {
      var rx1 = this.toScreenX(ev.region[0], b, pad, scale, offX);
      var rx2 = this.toScreenX(ev.region[1], b, pad, scale, offX);
      var rw = rx2 - rx1;
      ctx.fillStyle = 'rgba(239, 246, 255, 0.7)';
      ctx.fillRect(Math.min(rx1, rx2), 0, Math.abs(rw), this.height);
    }

    // 2. Draw strip band if event is strip or compare
    if (ev && (ev.type === 'strip' || ev.type === 'compare') && typeof ev.midX === 'number' && typeof ev.delta === 'number') {
      var sx1 = this.toScreenX(ev.midX - ev.delta, b, pad, scale, offX);
      var sx2 = this.toScreenX(ev.midX + ev.delta, b, pad, scale, offX);
      ctx.fillStyle = 'rgba(254, 240, 138, 0.45)'; // soft yellow band
      ctx.fillRect(Math.min(sx1, sx2), 0, Math.abs(sx2 - sx1), this.height);
    }

    // 3. Draw dividing lines (color-coded by depth)
    for (var l = 0; l < this.activeLines.length; l++) {
      var line = this.activeLines[l];
      var lx = this.toScreenX(line.x, b, pad, scale, offX);
      var color = DEPTH_COLORS[line.depth % DEPTH_COLORS.length];

      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.moveTo(lx, 0);
      ctx.lineTo(lx, this.height);
      ctx.stroke();
    }

    // 4. Draw points as small grey dots
    var dotRadius = this.isZoomed ? 3.5 : (this.points.length > 5000 ? 1 : 2);
    ctx.fillStyle = '#94a3b8';
    for (var p = 0; p < this.points.length; p++) {
      var pt = this.points[p];
      // Skip points outside zoomed view for rendering performance
      if (this.isZoomed && (pt[0] < b.minX || pt[0] > b.maxX || pt[1] < b.minY || pt[1] > b.maxY)) {
        continue;
      }
      var px = this.toScreenX(pt[0], b, pad, scale, offX);
      var py = this.toScreenY(pt[1], b, pad, scale, offY);

      ctx.beginPath();
      ctx.arc(px, py, dotRadius, 0, Math.PI * 2);
      ctx.fill();
    }

    // 5. Highlight base case points
    if (ev && ev.type === 'base' && ev.basePoints) {
      ctx.fillStyle = '#2563eb';
      for (var bp = 0; bp < ev.basePoints.length; bp++) {
        var bpt = ev.basePoints[bp];
        var bpx = this.toScreenX(bpt[0], b, pad, scale, offX);
        var bpy = this.toScreenY(bpt[1], b, pad, scale, offY);
        ctx.beginPath();
        ctx.arc(bpx, bpy, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 6. Draw candidate comparison line
    if (ev && ev.type === 'compare' && ev.p && ev.q) {
      var p1x = this.toScreenX(ev.p[0], b, pad, scale, offX);
      var p1y = this.toScreenY(ev.p[1], b, pad, scale, offY);
      var q1x = this.toScreenX(ev.q[0], b, pad, scale, offX);
      var q1y = this.toScreenY(ev.q[1], b, pad, scale, offY);

      ctx.beginPath();
      ctx.strokeStyle = ev.isNewBest ? '#16a34a' : '#f59e0b';
      ctx.lineWidth = 2;
      ctx.moveTo(p1x, p1y);
      ctx.lineTo(q1x, q1y);
      ctx.stroke();
    }

    // 7. Highlight best pair so far with rings and label
    var targetPair = (this.finalPair) ? this.finalPair : (ev && ev.bestPair ? ev.bestPair : null);
    var targetDist = (this.finalDistance !== null) ? this.finalDistance : (ev && ev.bestDistance !== Infinity ? ev.bestDistance : null);

    if (targetPair && targetPair[0] && targetPair[1]) {
      var pairP = targetPair[0];
      var pairQ = targetPair[1];

      var spx = this.toScreenX(pairP[0], b, pad, scale, offX);
      var spy = this.toScreenY(pairP[1], b, pad, scale, offY);
      var sqx = this.toScreenX(pairQ[0], b, pad, scale, offX);
      var sqy = this.toScreenY(pairQ[1], b, pad, scale, offY);

      // Connecting line
      ctx.beginPath();
      ctx.strokeStyle = '#16a34a';
      ctx.lineWidth = 2.5;
      ctx.moveTo(spx, spy);
      ctx.lineTo(sqx, sqy);
      ctx.stroke();

      // Rings around points
      [ [spx, spy], [sqx, sqy] ].forEach(function (coords) {
        ctx.beginPath();
        ctx.arc(coords[0], coords[1], 6, 0, Math.PI * 2);
        ctx.strokeStyle = '#16a34a';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(coords[0], coords[1], 10, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(22, 163, 74, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      });

      // Distance tag
      if (targetDist !== null && targetDist !== Infinity) {
        var label = 'd = ' + Math.sqrt(targetDist).toFixed(2);
        var labelX = (spx + sqx) / 2;
        var labelY = (spy + sqy) / 2 - 12;

        ctx.font = 'bold 12px sans-serif';
        var txtMetrics = ctx.measureText(label);
        var tw = txtMetrics.width;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.fillRect(labelX - tw / 2 - 4, labelY - 12, tw + 8, 16);
        ctx.strokeStyle = '#16a34a';
        ctx.lineWidth = 1;
        ctx.strokeRect(labelX - tw / 2 - 4, labelY - 12, tw + 8, 16);

        ctx.fillStyle = '#15803d';
        ctx.textAlign = 'center';
        ctx.fillText(label, labelX, labelY);
      }
    }
  };

  DAA.ClosestPairVisualizer = ClosestPairVisualizer;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}

