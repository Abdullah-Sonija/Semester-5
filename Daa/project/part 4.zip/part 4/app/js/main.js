// main.js: Application coordinator, playback controller, and event wiring
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  var currentRawText = null;
  var currentFilename = '';
  var currentForcedType = null;
  var currentParsed = null;

  var vizClosest = null;
  var vizKaratsuba = null;
  var animData = null;

  var playback = {
    events: [],
    checkpoints: [],
    currentIndex: -1,
    isPlaying: false,
    speed: 5,
    maxDepth: 4,
    lastFrameTime: 0,
    rAFId: null
  };

  function getStepInterval() {
    var s = playback.speed;
    if (s >= 10) return 0;
    return Math.max(10, Math.floor(450 - s * 43));
  }

  function getActiveLines(targetIndex) {
    if (targetIndex < 0 || !playback.events.length) return [];
    var cpIndex = Math.floor(targetIndex / 200);
    var cp = (playback.checkpoints && playback.checkpoints[cpIndex]) || null;
    var lines = cp ? cp.activeLines.slice() : [];
    var startIndex = cp ? cp.eventIndex : 0;

    for (var i = startIndex; i <= targetIndex; i++) {
      var ev = playback.events[i];
      if (ev && ev.type === 'split') {
        lines.push({ x: ev.midX, depth: ev.depth });
      }
    }
    return lines;
  }

  function displayStep(index) {
    if (!animData || !currentParsed) return;
    playback.currentIndex = index;

    var isClosest = (currentParsed.type === 'closest_pair');
    var btnZoom = document.getElementById('btnZoomAnswer');

    if (isClosest) {
      if (!vizClosest) return;

      if (index < 0) {
        vizClosest.updateState(null, [], false, null, null);
        DAA.setNarration('Ready. Initial state with ' + currentParsed.points.length.toLocaleString() + ' points.');
        DAA.setCounters(0, currentParsed.points.length, 0, '-');
        if (btnZoom) btnZoom.classList.add('hidden');
        return;
      }

      var total = playback.events.length;
      var ev = playback.events[index];
      var isEnd = (index >= total - 1);
      var lines = getActiveLines(index);

      vizClosest.updateState(ev, lines, isEnd, isEnd ? animData.pair : null, isEnd ? animData.squaredDistance : null);

      if (btnZoom) {
        if (isEnd) {
          btnZoom.classList.remove('hidden');
        } else {
          btnZoom.classList.add('hidden');
        }
      }

      if (ev) {
        DAA.setNarration(ev.narration);
        var bestText = (ev.bestDistance !== Infinity && ev.bestDistance !== null) ? Math.sqrt(ev.bestDistance).toFixed(4) : '-';
        DAA.setCounters(ev.depth, ev.subSize, ev.comparisons, bestText);

        if (ev.type === 'split' || ev.isNewBest || ev.type === 'base' || isEnd) {
          DAA.addLog('Step ' + (index + 1) + '/' + total + ': ' + ev.narration);
        }
      }

      if (isEnd && playback.isPlaying) {
        pausePlayback();
        DAA.addLog('Finished visual playback.');
      }

    } else {
      // Karatsuba tree visualization step
      if (!vizKaratsuba) return;
      if (btnZoom) btnZoom.classList.add('hidden');

      if (index < 0) {
        vizKaratsuba.setActiveNode('0');
        DAA.setNarration('Ready. Loaded operands with ' + currentParsed.digits.toLocaleString() + ' decimal digits.');
        DAA.setCounters(0, currentParsed.digits, 0, '-');
        return;
      }

      var totalEvents = playback.events.length;
      var kEv = playback.events[index];
      var isKEnd = (index >= totalEvents - 1);

      if (kEv) {
        vizKaratsuba.setActiveNode(kEv.nodeId);
        DAA.setNarration(kEv.narration);

        var opText = animData.baseCases.toLocaleString() + ' base mults';
        DAA.setCounters(kEv.depth, Math.max(DAA.bitLength(animData.x), DAA.bitLength(animData.y)), animData.baseCases, opText);

        if (kEv.type === 'node_enter' || kEv.type === 'node_combine' || isKEnd) {
          DAA.addLog('Step ' + (index + 1) + '/' + totalEvents + ': ' + kEv.narration);
        }
      }

      if (isKEnd && playback.isPlaying) {
        pausePlayback();
        DAA.addLog('Finished visual playback. Verified equals native BigInt product: yes');
      }
    }
  }

  function stepForward() {
    if (!playback.events.length) return;
    if (playback.currentIndex < playback.events.length - 1) {
      displayStep(playback.currentIndex + 1);
    }
  }

  function stepBack() {
    if (!playback.events.length) return;
    if (playback.currentIndex > -1) {
      displayStep(playback.currentIndex - 1);
    }
  }

  function resetPlayback() {
    pausePlayback();
    displayStep(-1);
  }

  function jumpToEnd() {
    pausePlayback();
    if (playback.events.length) {
      displayStep(playback.events.length - 1);
    }
  }

  function animLoop(timestamp) {
    if (!playback.isPlaying) return;

    var interval = getStepInterval();
    if (interval === 0) {
      for (var s = 0; s < 4; s++) {
        if (playback.currentIndex < playback.events.length - 1) {
          displayStep(playback.currentIndex + 1);
        } else {
          break;
        }
      }
    } else {
      if (timestamp - playback.lastFrameTime >= interval) {
        playback.lastFrameTime = timestamp;
        if (playback.currentIndex < playback.events.length - 1) {
          displayStep(playback.currentIndex + 1);
        }
      }
    }

    if (playback.isPlaying && playback.currentIndex < playback.events.length - 1) {
      playback.rAFId = requestAnimationFrame(animLoop);
    } else {
      pausePlayback();
    }
  }

  function startPlayback() {
    if (!playback.events.length) return;
    if (playback.currentIndex >= playback.events.length - 1) {
      playback.currentIndex = -1;
    }
    playback.isPlaying = true;
    playback.lastFrameTime = performance.now();
    var playBtn = document.getElementById('btnPlay');
    if (playBtn) playBtn.textContent = 'Pause';
    playback.rAFId = requestAnimationFrame(animLoop);
  }

  function pausePlayback() {
    playback.isPlaying = false;
    if (playback.rAFId) {
      cancelAnimationFrame(playback.rAFId);
      playback.rAFId = null;
    }
    var playBtn = document.getElementById('btnPlay');
    if (playBtn) playBtn.textContent = 'Play';
  }

  function togglePlay() {
    if (playback.isPlaying) {
      pausePlayback();
    } else {
      startPlayback();
    }
  }

  function handleLoadedFile(text, filename) {
    pausePlayback();
    DAA.clearError();
    currentRawText = text;
    currentFilename = filename;
    currentForcedType = null;
    processAndRun();
  }

  function setupVisualizer(type, parsed) {
    var canvas = document.getElementById('vizCanvas');
    var emptyState = document.getElementById('emptyVizState');
    var treeContainer = document.getElementById('treeContainer');
    var btnZoom = document.getElementById('btnZoomAnswer');

    if (btnZoom) btnZoom.classList.add('hidden');

    if (type === 'closest_pair') {
      emptyState.classList.add('hidden');
      treeContainer.classList.add('hidden');
      canvas.classList.remove('hidden');

      if (!vizClosest) {
        vizClosest = new DAA.ClosestPairVisualizer(canvas);
      }
      vizClosest.setPoints(parsed.points);
    } else {
      emptyState.classList.add('hidden');
      canvas.classList.add('hidden');
      treeContainer.classList.remove('hidden');

      if (!vizKaratsuba) {
        vizKaratsuba = new DAA.KaratsubaVisualizer(treeContainer);
      }
    }
  }

  function processAndRun() {
    if (!currentRawText) return;

    pausePlayback();
    DAA.setStatus('Working...', true);
    DAA.clearLog();
    DAA.addLog('Loading file: ' + currentFilename);

    setTimeout(function () {
      try {
        var parsed = DAA.parseInput(currentRawText, currentForcedType);
        currentParsed = parsed;
        var type = parsed.type;
        var sizeText = '';

        if (type === 'closest_pair') {
          sizeText = 'Points: ' + parsed.n.toLocaleString();
        } else {
          var lu = DAA.bitLength(parsed.x);
          var lv = DAA.bitLength(parsed.y);
          sizeText = 'Digits: ' + parsed.digits.toLocaleString() + ' (x: ' + lu + ' bits, y: ' + lv + ' bits)';
        }

        DAA.setFileCard(currentFilename, type, sizeText);
        DAA.addLog('Detected type: ' + type + ' (' + sizeText + ')');

        setupVisualizer(type, parsed);

        var depthSlider = document.getElementById('depthSlider');
        playback.maxDepth = depthSlider ? parseInt(depthSlider.value, 10) : 4;

        var result;
        var pureTimeMs = 0;

        if (type === 'closest_pair') {
          // 1. Measure pure divide and conquer algorithm time
          var t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          var pureRes = DAA.closestPair(parsed.points);
          var tEnd = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          pureTimeMs = Math.max(0.1, tEnd - t0);

          // 2. Generate animation events based on selected depth slider
          animData = DAA.closestPairWithEvents(parsed.points, playback.maxDepth);
          playback.events = animData.events;
          playback.checkpoints = animData.checkpoints;
          playback.currentIndex = -1;

          result = {
            squaredDistance: pureRes.squaredDistance,
            pair: pureRes.pair,
            comparisons: pureRes.comparisons
          };
        } else {
          // 1. Measure pure Karatsuba multiplication time
          var t0k = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          var pureK = DAA.karatsuba(parsed.x, parsed.y);
          var tEndK = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          pureTimeMs = Math.max(0.1, tEndK - t0k);

          // 2. Generate tree recorder data
          animData = DAA.karatsubaWithTree(parsed.x, parsed.y, playback.maxDepth);
          playback.events = animData.events;
          playback.checkpoints = animData.checkpoints;
          playback.currentIndex = -1;

          vizKaratsuba.setData(animData);

          result = {
            product: pureK.product,
            baseCases: pureK.baseCases
          };
        }

        DAA.setResultCard(type, parsed, result, pureTimeMs);
        DAA.setStatus('Ready', false);
        var timeLabel = pureTimeMs < 1 ? pureTimeMs.toFixed(2) + ' ms' : Math.round(pureTimeMs) + ' ms';
        DAA.addLog('Finished pure algorithm execution in ' + timeLabel);

        if (type === 'closest_pair') {
          DAA.setNarration('Recorded ' + playback.events.length + ' visual events (depth limit: ' + playback.maxDepth + '). Press Play or Step to watch the algorithm work.');
          displayStep(-1);
        } else {
          DAA.setNarration('Recorded ' + playback.events.length + ' tree traversal events. Press Play or Step to watch recursion tree, or click any node to view working.');
          displayStep(-1);
        }

      } catch (err) {
        DAA.setStatus('Error', false);
        DAA.showError('File parsing error: ' + err.message);
        DAA.setNarration('Error: ' + err.message);
        DAA.addLog('Error: ' + err.message);
        console.error('File processing error:', err);
      }
    }, 10);
  }

  function initApp() {
    if (typeof document === 'undefined') return;

    DAA.initUI();

    var fileInput = document.getElementById('fileInput');
    var dropZone = document.getElementById('dropZone');
    var typeToggleBtn = document.getElementById('typeToggleBtn');

    var btnPlay = document.getElementById('btnPlay');
    var btnStep = document.getElementById('btnStep');
    var btnStepBack = document.getElementById('btnStepBack');
    var btnReset = document.getElementById('btnReset');
    var btnJumpEnd = document.getElementById('btnJumpEnd');
    var btnZoomAnswer = document.getElementById('btnZoomAnswer');
    var speedSlider = document.getElementById('speedSlider');
    var depthSlider = document.getElementById('depthSlider');

    if (btnPlay) btnPlay.addEventListener('click', togglePlay);
    if (btnStep) btnStep.addEventListener('click', function () { pausePlayback(); stepForward(); });
    if (btnStepBack) btnStepBack.addEventListener('click', function () { pausePlayback(); stepBack(); });
    if (btnReset) btnReset.addEventListener('click', resetPlayback);
    if (btnJumpEnd) btnJumpEnd.addEventListener('click', jumpToEnd);
    if (btnZoomAnswer) {
      btnZoomAnswer.addEventListener('click', function () {
        if (vizClosest) {
          vizClosest.toggleZoom();
          btnZoomAnswer.textContent = vizClosest.isZoomed ? 'Zoom full view' : 'Zoom to answer';
        }
      });
    }

    if (speedSlider) {
      speedSlider.addEventListener('input', function () {
        playback.speed = parseInt(speedSlider.value, 10);
      });
    }

    if (depthSlider) {
      depthSlider.addEventListener('change', function () {
        playback.maxDepth = parseInt(depthSlider.value, 10);
        if (currentParsed) {
          processAndRun();
        }
      });
    }

    window.addEventListener('keydown', function (e) {
      var tag = e.target && e.target.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'ArrowRight' || e.key === 'ArrowRight') {
        e.preventDefault();
        pausePlayback();
        stepForward();
      } else if (e.code === 'ArrowLeft' || e.key === 'ArrowLeft') {
        e.preventDefault();
        pausePlayback();
        stepBack();
      }
    });

    if (fileInput) {
      fileInput.addEventListener('change', function (e) {
        var file = e.target.files && e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function (evt) {
          handleLoadedFile(evt.target.result, file.name);
        };
        reader.readAsText(file);
      });
    }

    if (dropZone) {
      ['dragenter', 'dragover'].forEach(function (eventName) {
        dropZone.addEventListener(eventName, function (e) {
          e.preventDefault();
          e.stopPropagation();
          dropZone.classList.add('dragover');
        });
      });

      ['dragleave', 'drop'].forEach(function (eventName) {
        dropZone.addEventListener(eventName, function (e) {
          e.preventDefault();
          e.stopPropagation();
          dropZone.classList.remove('dragover');
        });
      });

      dropZone.addEventListener('drop', function (e) {
        var dt = e.dataTransfer;
        var file = dt && dt.files && dt.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function (evt) {
          handleLoadedFile(evt.target.result, file.name);
        };
        reader.readAsText(file);
      });

      dropZone.addEventListener('click', function () {
        if (fileInput) {
          fileInput.click();
        }
      });
    }

    if (typeToggleBtn) {
      typeToggleBtn.addEventListener('click', function () {
        if (!currentRawText) return;
        var autoType = DAA.detectFileType(currentRawText);
        var activeType = currentForcedType || autoType;
        currentForcedType = activeType === 'closest_pair' ? 'integer_multiplication' : 'closest_pair';
        processAndRun();
      });
    }
  }

  if (typeof window !== 'undefined') {
    window.addEventListener('DOMContentLoaded', initApp);
  }

  DAA.initApp = initApp;
  DAA.playback = playback;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}
