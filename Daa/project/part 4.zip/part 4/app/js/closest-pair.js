// closest-pair.js: O(n log n) divide and conquer closest pair algorithm with event recording
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  // Squared Euclidean distance between points p and q
  function distanceSquared(p, q) {
    var dx = p[0] - q[0];
    var dy = p[1] - q[1];
    return dx * dx + dy * dy;
  }

  // Brute force check: O(n^2) search over all unique pairs
  function closestPairBruteForce(points) {
    var n = points.length;
    var best = Infinity;
    var pair = null;
    var comparisons = 0;

    for (var i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        comparisons++;
        var d = distanceSquared(points[i], points[j]);
        if (d < best) {
          best = d;
          pair = [points[i], points[j]];
        }
      }
    }

    return {
      squaredDistance: best,
      pair: pair,
      comparisons: comparisons
    };
  }

  // Divide and conquer closest pair algorithm: O(n log n)
  function closestPair(points) {
    var n = points.length;
    if (n < 2) {
      return {
        squaredDistance: Infinity,
        pair: null,
        comparisons: 0
      };
    }

    var indices = new Array(n);
    for (var i = 0; i < n; i++) {
      indices[i] = i;
    }

    var px = indices.slice().sort(function (a, b) {
      return points[a][0] - points[b][0] || points[a][1] - points[b][1] || a - b;
    });

    var py = indices.slice().sort(function (a, b) {
      return points[a][1] - points[b][1] || points[a][0] - points[b][0] || a - b;
    });

    var comparisons = 0;

    function recursiveSolve(subPx, subPy) {
      var count = subPx.length;

      if (count <= 3) {
        var baseBest = Infinity;
        var basePair = null;
        for (var a = 0; a < count; a++) {
          for (var b = a + 1; b < count; b++) {
            comparisons++;
            var dist = distanceSquared(points[subPx[a]], points[subPx[b]]);
            if (dist < baseBest) {
              baseBest = dist;
              basePair = [points[subPx[a]], points[subPx[b]]];
            }
          }
        }
        return { best: baseBest, pair: basePair };
      }

      var mid = count >> 1;
      var midX = points[subPx[mid]][0];
      var leftPx = subPx.slice(0, mid);
      var rightPx = subPx.slice(mid);

      var leftSet = new Set(leftPx);
      var leftPy = [];
      var rightPy = [];
      for (var k = 0; k < subPy.length; k++) {
        var idx = subPy[k];
        if (leftSet.has(idx)) {
          leftPy.push(idx);
        } else {
          rightPy.push(idx);
        }
      }

      var leftResult = recursiveSolve(leftPx, leftPy);
      var rightResult = recursiveSolve(rightPx, rightPy);

      var currentBest = leftResult.best <= rightResult.best ? leftResult.best : rightResult.best;
      var currentPair = leftResult.best <= rightResult.best ? leftResult.pair : rightResult.pair;

      var strip = [];
      for (var s = 0; s < subPy.length; s++) {
        var ptIdx = subPy[s];
        var dx = points[ptIdx][0] - midX;
        if (dx * dx < currentBest) {
          strip.push(ptIdx);
        }
      }

      for (var i = 0; i < strip.length; i++) {
        var p = points[strip[i]];
        for (var j = i + 1; j < strip.length; j++) {
          var q = points[strip[j]];
          var dy = q[1] - p[1];
          if (dy * dy >= currentBest) {
            break;
          }
          comparisons++;
          var d = distanceSquared(p, q);
          if (d < currentBest) {
            currentBest = d;
            currentPair = [p, q];
          }
        }
      }

      return { best: currentBest, pair: currentPair };
    }

    var finalResult = recursiveSolve(px, py);

    return {
      squaredDistance: finalResult.best,
      pair: finalResult.pair,
      comparisons: comparisons
    };
  }

  // Silent recursive solver used below max depth
  function silentSolve(points, subPx, subPy) {
    var count = subPx.length;
    if (count <= 3) {
      var baseBest = Infinity;
      var basePair = null;
      var baseComps = 0;
      for (var a = 0; a < count; a++) {
        for (var b = a + 1; b < count; b++) {
          baseComps++;
          var dist = distanceSquared(points[subPx[a]], points[subPx[b]]);
          if (dist < baseBest) {
            baseBest = dist;
            basePair = [points[subPx[a]], points[subPx[b]]];
          }
        }
      }
      return { best: baseBest, pair: basePair, comparisons: baseComps };
    }

    var mid = count >> 1;
    var midX = points[subPx[mid]][0];
    var leftPx = subPx.slice(0, mid);
    var rightPx = subPx.slice(mid);

    var leftSet = new Set(leftPx);
    var leftPy = [];
    var rightPy = [];
    for (var k = 0; k < subPy.length; k++) {
      var idx = subPy[k];
      if (leftSet.has(idx)) {
        leftPy.push(idx);
      } else {
        rightPy.push(idx);
      }
    }

    var leftResult = silentSolve(points, leftPx, leftPy);
    var rightResult = silentSolve(points, rightPx, rightPy);
    var comps = leftResult.comparisons + rightResult.comparisons;

    var currentBest = leftResult.best <= rightResult.best ? leftResult.best : rightResult.best;
    var currentPair = leftResult.best <= rightResult.best ? leftResult.pair : rightResult.pair;

    var strip = [];
    for (var s = 0; s < subPy.length; s++) {
      var ptIdx = subPy[s];
      var dx = points[ptIdx][0] - midX;
      if (dx * dx < currentBest) {
        strip.push(ptIdx);
      }
    }

    for (var i = 0; i < strip.length; i++) {
      var p = points[strip[i]];
      for (var j = i + 1; j < strip.length; j++) {
        var q = points[strip[j]];
        var dy = q[1] - p[1];
        if (dy * dy >= currentBest) {
          break;
        }
        comps++;
        var d = distanceSquared(p, q);
        if (d < currentBest) {
          currentBest = d;
          currentPair = [p, q];
        }
      }
    }

    return { best: currentBest, pair: currentPair, comparisons: comps };
  }

  // Divide and conquer closest pair with full event recording and checkpointing
  function closestPairWithEvents(points, maxDepth) {
    var animDepth = typeof maxDepth === 'number' ? maxDepth : 4;
    var n = points.length;

    if (n < 2) {
      return {
        squaredDistance: Infinity,
        pair: null,
        comparisons: 0,
        events: [],
        checkpoints: []
      };
    }

    var indices = new Array(n);
    for (var i = 0; i < n; i++) {
      indices[i] = i;
    }

    var px = indices.slice().sort(function (a, b) {
      return points[a][0] - points[b][0] || points[a][1] - points[b][1] || a - b;
    });

    var py = indices.slice().sort(function (a, b) {
      return points[a][1] - points[b][1] || points[a][0] - points[b][0] || a - b;
    });

    var events = [];
    var checkpoints = [];
    var comparisons = 0;
    var globalBestDist = Infinity;
    var globalBestPair = null;
    var activeLines = [];

    function saveCheckpointIfNeeded() {
      if (events.length % 200 === 0) {
        checkpoints.push({
          eventIndex: events.length,
          bestDistance: globalBestDist,
          bestPair: globalBestPair,
          comparisons: comparisons,
          activeLines: activeLines.slice()
        });
      }
    }

    function recordEvent(ev) {
      events.push(ev);
      saveCheckpointIfNeeded();
    }

    function solveWithEvents(subPx, subPy, depth, minX, maxX) {
      var count = subPx.length;

      // When recursion exceeds maxDepth, collapse subproblem into a single event
      if (depth > animDepth) {
        var silentRes = silentSolve(points, subPx, subPy);
        comparisons += silentRes.comparisons;
        var isNewGlobal = silentRes.best < globalBestDist;
        if (isNewGlobal) {
          globalBestDist = silentRes.best;
          globalBestPair = silentRes.pair;
        }
        recordEvent({
          type: 'collapsed',
          depth: depth,
          subSize: count,
          region: [minX, maxX],
          bestDistance: globalBestDist,
          bestPair: globalBestPair,
          comparisons: comparisons,
          narration: 'Depth ' + depth + ': Collapsed subproblem of ' + count + ' points. Local best distance: ' + (silentRes.best === Infinity ? 'none' : Math.sqrt(silentRes.best).toFixed(4)) + '.'
        });
        return { best: silentRes.best, pair: silentRes.pair };
      }

      // Base case: 3 or fewer points
      if (count <= 3) {
        var baseBest = Infinity;
        var basePair = null;
        var basePoints = [];
        for (var k = 0; k < count; k++) {
          basePoints.push(points[subPx[k]]);
        }

        for (var a = 0; a < count; a++) {
          for (var b = a + 1; b < count; b++) {
            comparisons++;
            var dist = distanceSquared(points[subPx[a]], points[subPx[b]]);
            if (dist < baseBest) {
              baseBest = dist;
              basePair = [points[subPx[a]], points[subPx[b]]];
            }
          }
        }

        if (baseBest < globalBestDist) {
          globalBestDist = baseBest;
          globalBestPair = basePair;
        }

        recordEvent({
          type: 'base',
          depth: depth,
          subSize: count,
          region: [minX, maxX],
          basePoints: basePoints,
          bestDistance: globalBestDist,
          bestPair: globalBestPair,
          comparisons: comparisons,
          narration: 'Depth ' + depth + ': Base case checked ' + count + ' points. Best distance: ' + (globalBestDist === Infinity ? 'none' : Math.sqrt(globalBestDist).toFixed(4)) + '.'
        });

        return { best: baseBest, pair: basePair };
      }

      // Divide: vertical dividing line at midX
      var mid = count >> 1;
      var midX = points[subPx[mid]][0];
      var leftPx = subPx.slice(0, mid);
      var rightPx = subPx.slice(mid);

      var leftSet = new Set(leftPx);
      var leftPy = [];
      var rightPy = [];
      for (var s = 0; s < subPy.length; s++) {
        var idx = subPy[s];
        if (leftSet.has(idx)) {
          leftPy.push(idx);
        } else {
          rightPy.push(idx);
        }
      }

      var lineObj = { x: midX, depth: depth };
      activeLines.push(lineObj);

      recordEvent({
        type: 'split',
        depth: depth,
        midX: midX,
        leftCount: leftPx.length,
        rightCount: rightPx.length,
        subSize: count,
        region: [minX, maxX],
        bestDistance: globalBestDist,
        bestPair: globalBestPair,
        comparisons: comparisons,
        narration: 'Depth ' + depth + ': Split at x = ' + midX.toLocaleString() + ' into ' + leftPx.length + ' left and ' + rightPx.length + ' right points.'
      });

      // Conquer left and right
      var leftResult = solveWithEvents(leftPx, leftPy, depth + 1, minX, midX);
      var rightResult = solveWithEvents(rightPx, rightPy, depth + 1, midX, maxX);

      var currentBest = leftResult.best <= rightResult.best ? leftResult.best : rightResult.best;
      var currentPair = leftResult.best <= rightResult.best ? leftResult.pair : rightResult.pair;
      if (currentBest < globalBestDist) {
        globalBestDist = currentBest;
        globalBestPair = currentPair;
      }

      // Merge: create strip
      var strip = [];
      for (var st = 0; st < subPy.length; st++) {
        var ptIdx = subPy[st];
        var dx = points[ptIdx][0] - midX;
        if (dx * dx < currentBest) {
          strip.push(ptIdx);
        }
      }

      var delta = Math.sqrt(currentBest);
      recordEvent({
        type: 'strip',
        depth: depth,
        midX: midX,
        delta: delta,
        stripCount: strip.length,
        subSize: count,
        region: [midX - delta, midX + delta],
        bestDistance: globalBestDist,
        bestPair: globalBestPair,
        comparisons: comparisons,
        narration: 'Depth ' + depth + ': Examining strip of width ' + (2 * delta).toFixed(1) + ' around x = ' + midX.toLocaleString() + ' with ' + strip.length + ' points.'
      });

      // Compare strip points
      for (var i = 0; i < strip.length; i++) {
        var p = points[strip[i]];
        for (var j = i + 1; j < strip.length; j++) {
          var q = points[strip[j]];
          var dy = q[1] - p[1];
          if (dy * dy >= currentBest) {
            break;
          }
          comparisons++;
          var d = distanceSquared(p, q);
          var isNewBest = false;
          if (d < currentBest) {
            currentBest = d;
            currentPair = [p, q];
            if (d < globalBestDist) {
              globalBestDist = d;
              globalBestPair = [p, q];
              isNewBest = true;
            }
          }
          recordEvent({
            type: 'compare',
            depth: depth,
            p: p,
            q: q,
            dist: d,
            isNewBest: isNewBest,
            subSize: count,
            region: [midX - delta, midX + delta],
            bestDistance: globalBestDist,
            bestPair: globalBestPair,
            comparisons: comparisons,
            narration: 'Depth ' + depth + ': Compared strip points (' + p[0] + ', ' + p[1] + ') and (' + q[0] + ', ' + q[1] + '), distance = ' + Math.sqrt(d).toFixed(4) + (isNewBest ? ' (New best!)' : '') + '.'
          });
        }
      }

      recordEvent({
        type: 'merge',
        depth: depth,
        subSize: count,
        region: [minX, maxX],
        bestDistance: globalBestDist,
        bestPair: globalBestPair,
        comparisons: comparisons,
        narration: 'Depth ' + depth + ': Merge completed. Current best distance: ' + Math.sqrt(globalBestDist).toFixed(4) + '.'
      });

      return { best: currentBest, pair: currentPair };
    }

    var globalMinX = points[px[0]][0];
    var globalMaxX = points[px[px.length - 1]][0];

    var finalRes = solveWithEvents(px, py, 0, globalMinX, globalMaxX);

    return {
      squaredDistance: finalRes.best,
      pair: finalRes.pair,
      comparisons: comparisons,
      events: events,
      checkpoints: checkpoints,
      points: points
    };
  }

  DAA.distanceSquared = distanceSquared;
  DAA.closestPair = closestPair;
  DAA.closestPairBruteForce = closestPairBruteForce;
  DAA.closestPairWithEvents = closestPairWithEvents;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}
