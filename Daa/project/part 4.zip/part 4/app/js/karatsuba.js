// karatsuba.js: BigInt Karatsuba integer multiplication algorithm with tree recorder
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  var BASE_BITS = 64;

  // Returns bit length of non-negative BigInt x
  function bitLength(x) {
    if (x === 0n) {
      return 0;
    }
    return x.toString(2).length;
  }

  // Grade school multiplication for checking small numbers (<= 4096 digits)
  function gradeSchool(xStr, yStr) {
    var aStr = (typeof xStr === 'string' ? xStr : xStr.toString()).trim();
    var bStr = (typeof yStr === 'string' ? yStr : yStr.toString()).trim();

    var a = [];
    var b = [];
    for (var i = aStr.length - 1; i >= 0; i--) {
      a.push(parseInt(aStr[i], 10));
    }
    for (var j = bStr.length - 1; j >= 0; j--) {
      b.push(parseInt(bStr[j], 10));
    }

    var res = new Array(a.length + b.length);
    for (var k = 0; k < res.length; k++) {
      res[k] = 0;
    }

    for (var ia = 0; ia < a.length; ia++) {
      var carry = 0;
      var da = a[ia];
      for (var ib = 0; ib < b.length; ib++) {
        var cur = res[ia + ib] + da * b[ib] + carry;
        res[ia + ib] = cur % 10;
        carry = Math.floor(cur / 10);
      }
      res[ia + b.length] += carry;
    }

    var rev = [];
    for (var r = res.length - 1; r >= 0; r--) {
      rev.push(res[r]);
    }
    var s = rev.join('').replace(/^0+/, '');
    var finalStr = s.length > 0 ? s : '0';

    return {
      product: BigInt(finalStr),
      productStr: finalStr,
      digitMultiplications: a.length * b.length
    };
  }

  // Plain Karatsuba multiplication using binary splitting
  function karatsuba(x, y) {
    var bx = typeof x === 'bigint' ? x : BigInt(x);
    var by = typeof y === 'bigint' ? y : BigInt(y);

    var stats = { baseCases: 0 };

    function rec(u, v) {
      var lu = bitLength(u);
      var lv = bitLength(v);

      if (lu <= BASE_BITS || lv <= BASE_BITS) {
        stats.baseCases++;
        return u * v;
      }

      var maxBits = lu > lv ? lu : lv;
      var m = BigInt(Math.floor(maxBits / 2));
      var mask = (1n << m) - 1n;

      var a = u >> m;
      var b = u & mask;
      var c = v >> m;
      var d = v & mask;

      var ac = rec(a, c);
      var bd = rec(b, d);
      var mid = rec(a + b, c + d) - ac - bd;

      return (ac << (2n * m)) + (mid << m) + bd;
    }

    var prod = rec(bx, by);

    return {
      product: prod,
      baseCases: stats.baseCases
    };
  }

  // Karatsuba with call tree and event recorder
  // Stores full node data only for depths <= 4
  // For deeper calls, purely updates per-depth counters
  function karatsubaWithTree(x, y, maxRecordDepth) {
    var recordDepthLimit = typeof maxRecordDepth === 'number' ? maxRecordDepth : 4;
    var bx = typeof x === 'bigint' ? x : BigInt(x);
    var by = typeof y === 'bigint' ? y : BigInt(y);

    var depthStats = [];
    var events = [];
    var checkpoints = [];
    var totalBaseCases = 0;

    function ensureDepthStat(d, bits) {
      while (depthStats.length <= d) {
        depthStats.push({ depth: depthStats.length, calls: 0, operandBits: 0, baseCases: 0 });
      }
      depthStats[d].calls++;
      if (depthStats[d].operandBits === 0 || bits > depthStats[d].operandBits) {
        depthStats[d].operandBits = bits;
      }
    }

    function recordEvent(ev) {
      events.push(ev);
      if (events.length % 200 === 0) {
        checkpoints.push({
          eventIndex: events.length,
          activeNodeId: ev.nodeId,
          totalBaseCases: totalBaseCases
        });
      }
    }

    // Fast silent execution for depths beyond recordDepthLimit
    function silentKaratsuba(u, v, d) {
      var lu = bitLength(u);
      var lv = bitLength(v);
      var maxBits = lu > lv ? lu : lv;
      ensureDepthStat(d, maxBits);

      if (lu <= BASE_BITS || lv <= BASE_BITS) {
        totalBaseCases++;
        depthStats[d].baseCases++;
        return { product: u * v, baseCases: 1 };
      }

      var m = BigInt(Math.floor(maxBits / 2));
      var mask = (1n << m) - 1n;

      var a = u >> m;
      var b = u & mask;
      var c = v >> m;
      var dVal = v & mask;

      var rAc = silentKaratsuba(a, c, d + 1);
      var rBd = silentKaratsuba(b, dVal, d + 1);
      var rMid = silentKaratsuba(a + b, c + dVal, d + 1);

      var subProd = (rAc.product << (2n * m)) + ((rMid.product - rAc.product - rBd.product) << m) + rBd.product;
      var subBases = rAc.baseCases + rBd.baseCases + rMid.baseCases;

      return { product: subProd, baseCases: subBases };
    }

    // Instrumented recursive solver that creates tree nodes and events
    function recTree(u, v, d, id, role, roleLabel) {
      var lu = bitLength(u);
      var lv = bitLength(v);
      var maxBits = lu > lv ? lu : lv;
      ensureDepthStat(d, maxBits);

      var node = {
        id: id,
        depth: d,
        role: role,
        roleLabel: roleLabel,
        u: u,
        v: v,
        uBits: lu,
        vBits: lv,
        isBase: false,
        m: 0n,
        a: 0n,
        b: 0n,
        c: 0n,
        d: 0n,
        ac: 0n,
        bd: 0n,
        midProduct: 0n,
        result: 0n,
        children: [],
        subBaseCases: 0
      };

      // Base case check
      if (lu <= BASE_BITS || lv <= BASE_BITS) {
        node.isBase = true;
        totalBaseCases++;
        depthStats[d].baseCases++;
        node.result = u * v;
        node.subBaseCases = 1;

        if (d <= 3) {
          recordEvent({
            type: 'node_base',
            nodeId: id,
            depth: d,
            role: role,
            roleLabel: roleLabel,
            result: node.result,
            narration: 'Depth ' + d + ' (' + roleLabel + '): Base case evaluated directly (<= 64 bits).'
          });
        }
        return node;
      }

      var m = BigInt(Math.floor(maxBits / 2));
      var mask = (1n << m) - 1n;
      node.m = m;
      node.a = u >> m;
      node.b = u & mask;
      node.c = v >> m;
      node.d = v & mask;

      if (d <= 3) {
        recordEvent({
          type: 'node_enter',
          nodeId: id,
          depth: d,
          role: role,
          roleLabel: roleLabel,
          m: m,
          uBits: lu,
          vBits: lv,
          narration: 'Depth ' + d + ' (' + roleLabel + '): Entering subproblem with ' + lu + ' and ' + lv + ' bit operands.'
        });

        recordEvent({
          type: 'node_split',
          nodeId: id,
          depth: d,
          role: role,
          roleLabel: roleLabel,
          m: m,
          a: node.a,
          b: node.b,
          c: node.c,
          d: node.d,
          narration: 'Depth ' + d + ' (' + roleLabel + '): Split at m = ' + m + ' bits. Spawning a*c, b*d, and (a+b)*(c+d).'
        });
      }

      var acNode, bdNode, midNode;
      var acProd, bdProd, midProd;
      var totalSubBases = 0;

      if (d + 1 <= recordDepthLimit) {
        acNode = recTree(node.a, node.c, d + 1, id + '-0', 'ac', 'a*c');
        bdNode = recTree(node.b, node.d, d + 1, id + '-1', 'bd', 'b*d');
        midNode = recTree(node.a + node.b, node.c + node.d, d + 1, id + '-2', 'mid', '(a+b)*(c+d)');

        node.children = [acNode, bdNode, midNode];
        acProd = acNode.result;
        bdProd = bdNode.result;
        midProd = midNode.result;
        totalSubBases = acNode.subBaseCases + bdNode.subBaseCases + midNode.subBaseCases;
      } else {
        // Switch to silent computation for deeper levels
        var sAc = silentKaratsuba(node.a, node.c, d + 1);
        var sBd = silentKaratsuba(node.b, node.d, d + 1);
        var sMid = silentKaratsuba(node.a + node.b, node.c + node.d, d + 1);

        acProd = sAc.product;
        bdProd = sBd.product;
        midProd = sMid.product;
        totalSubBases = sAc.baseCases + sBd.baseCases + sMid.baseCases;
      }

      node.ac = acProd;
      node.bd = bdProd;
      node.midProduct = midProd - acProd - bdProd;
      node.result = (acProd << (2n * m)) + (node.midProduct << m) + bdProd;
      node.subBaseCases = totalSubBases;

      if (d <= 3) {
        recordEvent({
          type: 'node_combine',
          nodeId: id,
          depth: d,
          role: role,
          roleLabel: roleLabel,
          m: m,
          ac: node.ac,
          bd: node.bd,
          midProduct: node.midProduct,
          result: node.result,
          narration: 'Depth ' + d + ' (' + roleLabel + '): Combined subproducts using shifts and addition.'
        });
      }

      return node;
    }

    var rootNode = recTree(bx, by, 0, '0', 'root', 'x * y');

    recordEvent({
      type: 'tree_complete',
      nodeId: '0',
      depth: 0,
      role: 'root',
      roleLabel: 'x * y',
      result: rootNode.result,
      narration: 'Karatsuba complete. Final product computed successfully.'
    });

    return {
      product: rootNode.result,
      baseCases: totalBaseCases,
      depthStats: depthStats,
      tree: rootNode,
      events: events,
      checkpoints: checkpoints,
      x: bx,
      y: by
    };
  }

  DAA.BASE_BITS = BASE_BITS;
  DAA.bitLength = bitLength;
  DAA.gradeSchool = gradeSchool;
  DAA.karatsuba = karatsuba;
  DAA.karatsubaWithTree = karatsubaWithTree;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}
