// ui.js: UI state management, tab handling, and view updates
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  var dom = {};

  function initUI() {
    dom.fileCard = document.getElementById('fileCard');
    dom.fileNameDisplay = document.getElementById('fileNameDisplay');
    dom.typeBadge = document.getElementById('typeBadge');
    dom.typeToggleBtn = document.getElementById('typeToggleBtn');
    dom.fileMetaDisplay = document.getElementById('fileMetaDisplay');

    dom.resultCard = document.getElementById('resultCard');
    dom.resultAnswer = document.getElementById('resultAnswer');
    dom.resultTime = document.getElementById('resultTime');
    dom.resultRecurrence = document.getElementById('resultRecurrence');
    dom.btnBruteForce = document.getElementById('btnBruteForce');
    dom.comparisonNote = document.getElementById('comparisonNote');
    dom.comparisonResult = document.getElementById('comparisonResult');

    dom.statusIndicator = document.getElementById('statusIndicator');
    dom.narrationText = document.getElementById('narrationText');
    dom.cntDepth = document.getElementById('cntDepth');
    dom.cntSubSize = document.getElementById('cntSubSize');
    dom.cntOps = document.getElementById('cntOps');
    dom.cntBest = document.getElementById('cntBest');
    dom.logList = document.getElementById('logList');

    dom.speedSlider = document.getElementById('speedSlider');
    dom.speedValue = document.getElementById('speedValue');
    dom.depthSlider = document.getElementById('depthSlider');
    dom.depthValue = document.getElementById('depthValue');
    dom.errorBanner = document.getElementById('errorBanner');

    setupTabs();
    setupSliders();
  }

  function showError(msg) {
    if (!dom.errorBanner) return;
    dom.errorBanner.textContent = msg;
    dom.errorBanner.classList.remove('hidden');
  }

  function clearError() {
    if (!dom.errorBanner) return;
    dom.errorBanner.textContent = '';
    dom.errorBanner.classList.add('hidden');
  }

  function setupTabs() {
    var tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var targetId = btn.getAttribute('data-tab');
        document.querySelectorAll('.tab-btn').forEach(function (b) {
          b.classList.remove('active');
        });
        document.querySelectorAll('.tab-panel').forEach(function (p) {
          p.classList.remove('active');
        });
        btn.classList.add('active');
        var targetPanel = document.getElementById(targetId);
        if (targetPanel) {
          targetPanel.classList.add('active');
        }
      });
    });
  }

  function setupSliders() {
    if (dom.speedSlider && dom.speedValue) {
      dom.speedSlider.addEventListener('input', function () {
        dom.speedValue.textContent = dom.speedSlider.value + 'x';
      });
    }
    if (dom.depthSlider && dom.depthValue) {
      dom.depthSlider.addEventListener('input', function () {
        dom.depthValue.textContent = dom.depthSlider.value;
      });
    }
  }

  function setStatus(text, isBusy) {
    if (!dom.statusIndicator) return;
    dom.statusIndicator.textContent = text;
    if (isBusy) {
      dom.statusIndicator.style.backgroundColor = '#fef3c7';
      dom.statusIndicator.style.color = '#92400e';
    } else {
      dom.statusIndicator.style.backgroundColor = '#e2e8f0';
      dom.statusIndicator.style.color = '#475569';
    }
  }

  function setFileCard(filename, type, sizeText) {
    if (!dom.fileCard) return;
    dom.fileCard.classList.remove('hidden');
    dom.fileNameDisplay.textContent = filename;

    dom.typeBadge.className = 'badge';
    if (type === 'closest_pair') {
      dom.typeBadge.classList.add('badge-closest');
      dom.typeBadge.textContent = 'Closest Pair';
      dom.typeToggleBtn.textContent = 'Switch to Integer Multiplication';
    } else {
      dom.typeBadge.classList.add('badge-karatsuba');
      dom.typeBadge.textContent = 'Integer Multiplication';
      dom.typeToggleBtn.textContent = 'Switch to Closest Pair';
    }

    dom.fileMetaDisplay.textContent = sizeText;
  }

  function formatShortNumber(numStr, maxLen) {
    if (!numStr) return '';
    var s = numStr.toString();
    if (s.length <= maxLen) return s;
    var half = Math.floor((maxLen - 3) / 2);
    return s.slice(0, half) + '...' + s.slice(-half) + ' (' + s.length + ' digits)';
  }

  function setResultCard(type, parsedData, result, elapsedMs) {
    if (!dom.resultCard) return;
    dom.resultCard.classList.remove('hidden');

    var formattedTime = (typeof elapsedMs === 'number') ?
      (elapsedMs < 1 ? elapsedMs.toFixed(2) + ' ms' : Math.round(elapsedMs) + ' ms') :
      elapsedMs + ' ms';

    dom.resultTime.textContent = formattedTime;
    dom.comparisonResult.classList.add('hidden');
    dom.comparisonResult.textContent = '';

    if (type === 'closest_pair') {
      var d = result.squaredDistance;
      var dist = Math.sqrt(d).toFixed(4);
      var p1 = result.pair ? '(' + result.pair[0][0] + ', ' + result.pair[0][1] + ')' : 'none';
      var p2 = result.pair ? '(' + result.pair[1][0] + ', ' + result.pair[1][1] + ')' : 'none';

      dom.resultAnswer.innerHTML = 'Distance: <strong>' + dist + '</strong> (squared: ' + d + ')<br>Points: ' + p1 + ' and ' + p2;
      dom.resultRecurrence.textContent = 'T(n) = 2T(n/2) + O(n) => O(n log n)';

      // Brute force check configuration
      if (parsedData.n <= 5000) {
        dom.btnBruteForce.disabled = false;
        dom.comparisonNote.textContent = 'Brute force available (up to 5,000 points).';
        dom.btnBruteForce.onclick = function () {
          var t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          var bf = DAA.closestPairBruteForce(parsedData.points);
          var tEnd = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          var bfTime = Math.max(0.1, tEnd - t0);
          var bfTimeFormatted = bfTime < 1 ? bfTime.toFixed(2) + ' ms' : Math.round(bfTime) + ' ms';
          var match = bf.squaredDistance === result.squaredDistance;
          var speedup = (bfTime / Math.max(0.1, elapsedMs)).toFixed(1);

          dom.comparisonResult.classList.remove('hidden');
          dom.comparisonResult.innerHTML =
            '<div style="margin-bottom:4px"><strong>Divide &amp; Conquer:</strong> ' + formattedTime + ' (' + result.comparisons.toLocaleString() + ' distance checks)</div>' +
            '<div style="margin-bottom:4px"><strong>Brute Force:</strong> ' + bfTimeFormatted + ' (' + bf.comparisons.toLocaleString() + ' distance checks)</div>' +
            '<div><strong>Result:</strong> ' + (match ? '<span style="color:var(--success);font-weight:600">Distances match exactly</span>' : '<span style="color:var(--error);font-weight:600">Mismatch</span>') + ' (D&amp;C is roughly <strong>' + speedup + 'x</strong> faster)</div>';
        };
      } else {
        dom.btnBruteForce.disabled = true;
        dom.comparisonNote.textContent = 'Note: Brute force check is disabled for n > 5,000 points (would be slow).';
      }

    } else if (type === 'integer_multiplication') {
      var prodStr = result.product.toString();
      var preview = formatShortNumber(prodStr, 40);
      var nativeMatch = result.product === (parsedData.x * parsedData.y);

      dom.resultAnswer.innerHTML = 'Product: <strong>' + preview + '</strong><br>Base case multiplications: ' + result.baseCases + '<br>Equals native BigInt product: ' + (nativeMatch ? '<span style="color:var(--success)">yes</span>' : '<span style="color:var(--error)">no</span>');
      dom.resultRecurrence.textContent = 'T(n) = 3T(n/2) + O(n) => O(n^1.585)';

      // Grade school check configuration
      if (parsedData.digits <= 4096) {
        dom.btnBruteForce.disabled = false;
        dom.comparisonNote.textContent = 'Grade school check available (up to 4,096 digits).';
        dom.btnBruteForce.onclick = function () {
          var t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          var gs = DAA.gradeSchool(parsedData.xStr, parsedData.yStr);
          var tEnd = (typeof performance !== 'undefined' ? performance.now() : Date.now());
          var gsTime = Math.max(0.1, tEnd - t0);
          var gsTimeFormatted = gsTime < 1 ? gsTime.toFixed(2) + ' ms' : Math.round(gsTime) + ' ms';
          var match = gs.product === result.product;
          var speedup = (gsTime / Math.max(0.1, elapsedMs)).toFixed(1);

          dom.comparisonResult.classList.remove('hidden');
          dom.comparisonResult.innerHTML =
            '<div style="margin-bottom:4px"><strong>Karatsuba D&amp;C:</strong> ' + formattedTime + ' (' + result.baseCases.toLocaleString() + ' base mults)</div>' +
            '<div style="margin-bottom:4px"><strong>Grade School:</strong> ' + gsTimeFormatted + ' (' + gs.digitMultiplications.toLocaleString() + ' digit mults)</div>' +
            '<div><strong>Result:</strong> ' + (match ? '<span style="color:var(--success);font-weight:600">Products match exactly</span>' : '<span style="color:var(--error);font-weight:600">Mismatch</span>') + ' (Karatsuba is roughly <strong>' + speedup + 'x</strong> faster)</div>';
        };
      } else {
        dom.btnBruteForce.disabled = true;
        dom.comparisonNote.textContent = 'Note: Grade school multiplication disabled for n > 4,096 digits (would be slow).';
      }
    }
  }

  function setNarration(text) {
    if (dom.narrationText) {
      dom.narrationText.textContent = text;
    }
  }

  function setCounters(depth, subSize, ops, best) {
    if (dom.cntDepth) dom.cntDepth.textContent = depth;
    if (dom.cntSubSize) dom.cntSubSize.textContent = subSize;
    if (dom.cntOps) dom.cntOps.textContent = ops;
    if (dom.cntBest) dom.cntBest.textContent = best;
  }

  function addLog(text) {
    if (!dom.logList) return;
    var li = document.createElement('li');
    li.className = 'log-item';
    li.textContent = text;
    dom.logList.appendChild(li);
    dom.logList.parentElement.scrollTop = dom.logList.parentElement.scrollHeight;
  }

  function clearLog() {
    if (!dom.logList) return;
    dom.logList.innerHTML = '';
  }

  DAA.initUI = initUI;
  DAA.setStatus = setStatus;
  DAA.setFileCard = setFileCard;
  DAA.setResultCard = setResultCard;
  DAA.setNarration = setNarration;
  DAA.setCounters = setCounters;
  DAA.addLog = addLog;
  DAA.clearLog = clearLog;
  DAA.showError = showError;
  DAA.clearError = clearError;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}

