// parser.js: input file parser and auto-detection
var DAA = (typeof globalThis !== 'undefined' && globalThis.DAA) || (typeof window !== 'undefined' && window.DAA) || (typeof global !== 'undefined' && global.DAA) || {};
if (typeof globalThis !== 'undefined') {
  globalThis.DAA = DAA;
}

(function () {
  'use strict';

  // Normalize line endings and filter out empty trailing lines
  function getCleanLines(rawText) {
    if (!rawText || typeof rawText !== 'string') {
      return [];
    }
    var lines = rawText.split(/\r?\n/);
    var cleaned = [];
    for (var i = 0; i < lines.length; i++) {
      var trimmed = lines[i].trim();
      if (trimmed.length > 0) {
        cleaned.push(trimmed);
      }
    }
    return cleaned;
  }

  // Detect file type based on line 2 content
  // If line 2 contains a space, it is closest pair. Otherwise, integer multiplication.
  function detectFileType(rawText) {
    var lines = getCleanLines(rawText);
    if (lines.length < 2) {
      return null;
    }
    var secondLine = lines[1];
    if (secondLine.indexOf(' ') !== -1) {
      return 'closest_pair';
    }
    return 'integer_multiplication';
  }

  // Parse closest pair file
  // Line 1: n
  // Next n lines: "x y"
  function parseClosestPair(rawText) {
    var lines = getCleanLines(rawText);
    if (lines.length === 0) {
      throw new Error('Input file is empty. Expected point count on line 1.');
    }
    var n = parseInt(lines[0], 10);
    if (isNaN(n) || n <= 0) {
      throw new Error('Invalid format: line 1 must specify positive point count n.');
    }
    var points = [];
    var limit = Math.min(lines.length - 1, n);
    for (var i = 1; i <= limit; i++) {
      var parts = lines[i].split(/\s+/);
      if (parts.length >= 2) {
        var x = parseInt(parts[0], 10);
        var y = parseInt(parts[1], 10);
        if (!isNaN(x) && !isNaN(y)) {
          points.push([x, y]);
        }
      }
    }
    if (points.length < 2) {
      throw new Error('At least 2 points are required to compute closest pair.');
    }
    return {
      type: 'closest_pair',
      n: points.length,
      points: points
    };
  }

  // Parse integer multiplication file
  // Line 1: number of digits n
  // Line 2: first number (n digits)
  // Line 3: second number (n digits)
  function parseIntegerMultiplication(rawText) {
    var lines = getCleanLines(rawText);
    if (lines.length < 3) {
      throw new Error('Invalid format: integer multiplication requires digit count and two operands.');
    }
    var digits = parseInt(lines[0], 10);
    if (isNaN(digits) || digits <= 0) {
      throw new Error('Invalid format: line 1 must specify positive digit count.');
    }
    var xs = lines[1].replace(/[^0-9]/g, '');
    var ys = lines[2].replace(/[^0-9]/g, '');
    if (!xs || !ys) {
      throw new Error('Operands must contain valid decimal digits.');
    }
    var x = BigInt(xs);
    var y = BigInt(ys);
    return {
      type: 'integer_multiplication',
      digits: digits,
      xStr: xs,
      yStr: ys,
      x: x,
      y: y
    };
  }

  // High-level parser that uses detection or an optional user override
  function parseInput(rawText, overrideType) {
    if (!rawText || !rawText.trim()) {
      throw new Error('The selected file is empty.');
    }
    var detected = overrideType || detectFileType(rawText);
    if (!detected) {
      throw new Error('Unrecognized file format. Expected points or integer multiplication data.');
    }
    if (detected === 'closest_pair') {
      var cpResult = parseClosestPair(rawText);
      cpResult.detectedType = detected;
      return cpResult;
    } else if (detected === 'integer_multiplication') {
      var imResult = parseIntegerMultiplication(rawText);
      imResult.detectedType = detected;
      return imResult;
    }
    throw new Error('Unsupported problem type: ' + detected);
  }

  DAA.getCleanLines = getCleanLines;
  DAA.detectFileType = detectFileType;
  DAA.parseClosestPair = parseClosestPair;
  DAA.parseIntegerMultiplication = parseIntegerMultiplication;
  DAA.parseInput = parseInput;

})();

if (typeof module !== 'undefined') {
  module.exports = DAA;
}
