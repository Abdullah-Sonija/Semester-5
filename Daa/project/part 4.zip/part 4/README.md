# DAA Project - Part 4: Divide and Conquer Visualizer

A responsive, standalone offline web application demonstrating the visual execution of two fundamental divide-and-conquer algorithms:
1. **Closest Pair of Points in 2D**: $O(n \log n)$ divide-and-conquer algorithm with recursion divider rendering, subproblem shading, strip inspection bands, candidate point-pair checks, and final closest pair highlighting.
2. **Karatsuba Integer Multiplication**: $O(n^{\log_2 3}) \approx O(n^{1.585})$ fast integer multiplication with interactive 4-level recursion tree navigation, subtree node breakdown, mathematical formula inspection ($a \cdot c$, $b \cdot d$, $(a+b)(c+d)$), and recursive level analysis tables.

---

## Deliverables & Architecture
- **Zero External Dependencies**: Pure HTML5, CSS3, and standard vanilla JavaScript. No external libraries, frameworks, CDNs, or npm packages.
- **100% Offline**: Can be launched directly from disk using `file://` protocol.
- **Dual Runtime**: All algorithmic modules run identically in modern browsers and in Node.js test runners.
- **Responsive Layout**: Designed for mobile, tablet, and desktop viewports (tested at 360px, 768px, and 1280px+).

---

## How to Run the Visualizer

### Option 1: Direct in Browser (No Server Needed)
1. Double-click `index.html` in this folder, or open `app/index.html` directly in any web browser (Chrome, Edge, Firefox, Safari).
2. The user interface will load immediately.

### Option 2: Run Algorithmic Tests (Node.js)
To verify algorithm correctness and event tracking across all 20 benchmark test datasets:
```bash
node app/tests/run-tests.js
```
Expected output: `40 passed, 0 failed`.

---

## How to Use the Application

1. **Load a Dataset**:
   - Click **Choose file** (or drag and drop) and select any test file from `sample_data/closest_pair/` or `sample_data/integer_multiplication/`.
   - The application automatically detects whether the file is a 2D point set or an integer multiplication problem.
2. **Playback Controls**:
   - **Play / Pause**: Start or stop automated step-by-step playback (Keyboard: `Space`).
   - **Step Forward / Step Back**: Advance or rewind by individual algorithmic events (Keyboard: `Right Arrow` / `Left Arrow`).
   - **Reset**: Reset visualization to step 0.
   - **Jump to End**: Instantly display the completed result.
   - **Speed**: Adjust animation pacing from 1x to 10x.
   - **Animate Depth Up To**: Control how deep recursion is rendered before subproblems silently collapse into single summary steps.
3. **Interactive Inspection**:
   - **Closest Pair**: View the vertical split boundaries colored by recursion level, yellow strip search windows, and zoom in on the final closest pair.
   - **Karatsuba**: Click any node on the recursion tree to inspect its operand splits ($a, b, c, d$), intermediate products, and recombined shifts.
4. **Brute Force Verification**:
   - Click **Run brute force check** on the results card to independently verify divide-and-conquer solutions against naive $O(n^2)$ implementations.

---

## Directory Structure

```text
part 4/
├── index.html                 # Launcher redirecting to app/index.html
├── README.md                  # Project documentation and user guide
├── app/
│   ├── index.html             # Main visualizer web interface
│   ├── README.md              # Detailed app specifications
│   ├── css/
│   │   └── style.css          # Responsive styling and themes
│   ├── js/
│   │   ├── closest-pair.js    # Closest pair algorithm and event recorder
│   │   ├── karatsuba.js       # Karatsuba multiplication and recursion tree builder
│   │   ├── parser.js          # File input parsing and auto-detection
│   │   └── main.js            # UI controller, playback, canvas and SVG rendering
│   └── tests/
│       └── run-tests.js       # Node.js automated test runner (40 tests)
├── reference/
│   └── expected.json          # Benchmark solutions for validation
└── sample_data/
    ├── closest_pair/          # 10 test datasets (150 to 15,000 points)
    └── integer_multiplication/# 10 test datasets (128 to 65,536 bits)
```
