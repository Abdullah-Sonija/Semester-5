"""
Roll Number: 24k-0013
Seed: 0013 (13)
Parameters: 200 packets, N=4, k=3, timeout=1.0s
Conditions:
  A. Reliable channel (no loss or corruption)
  B. Packet loss (loss 0.10)
  C. Mixed errors (loss 0.05, corruption 0.05, delay 0.10)
"""

import matplotlib.pyplot as plt
import numpy as np
from task3 import run_simulation

scenarios = [
    {
        "name": "A. Reliable Channel",
        "loss": 0.0,
        "corrupt": 0.0,
        "delay": 0.0,
        "label": "Reliable"
    },
    {
        "name": "B. Packet Loss (10%)",
        "loss": 0.10,
        "corrupt": 0.0,
        "delay": 0.0,
        "label": "Loss 10%"
    },
    {
        "name": "C. Mixed Errors",
        "loss": 0.05,
        "corrupt": 0.05,
        "delay": 0.10,
        "label": "Mixed Errors"
    }
]

results = []

for sc in scenarios:
    print(f"\n>>>> Running Scenario: {sc['name']} <<<<")
    # Run GBN
    gbn_res = run_simulation(
        protocol="gbn",
        num_packets=200,
        N=4,
        k=3,
        loss_prob=sc["loss"],
        corrupt_prob=sc["corrupt"],
        delay_prob=sc["delay"],
        timeout=1.0,
        seed=13
    )
    # Run SR
    sr_res = run_simulation(
        protocol="sr",
        num_packets=200,
        N=4,
        k=3,
        loss_prob=sc["loss"],
        corrupt_prob=sc["corrupt"],
        delay_prob=sc["delay"],
        timeout=1.0,
        seed=13
    )
    results.append({
        "scenario": sc["name"],
        "label": sc["label"],
        "gbn": gbn_res,
        "sr": sr_res
    })

print("\n" + "=" * 80)
print("EXPERIMENT RESULTS TABLE")
print("=" * 80)
print(f"{'Condition':<25} | {'Protocol':<5} | {'Tx Pkts':<8} | {'Retrans':<8} | {'Delivered':<10} | {'Time (s)':<9} | {'Throughput (p/s)':<16}")
print("-" * 88)
for r in results:
    for proto in ["gbn", "sr"]:
        d = r[proto]
        print(f"{r['scenario']:<25} | {proto.upper():<5} | {d['transmitted']:<8} | {d['retransmissions']:<8} | {d['delivered']:<10} | {d['time']:<9.2f} | {d['throughput']:<16.2f}")
    print("-" * 88)

# ----------------- Generate Graphs -----------------
fig, axes = plt.subplots(1, 2, figsize=(13, 5), dpi=300)

labels = [r["label"] for r in results]
x = np.arange(len(labels))
width = 0.35

# Plot 1: Retransmissions
gbn_retrans = [r["gbn"]["retransmissions"] for r in results]
sr_retrans = [r["sr"]["retransmissions"] for r in results]

axes[0].bar(x - width/2, gbn_retrans, width, label='Go-Back-N (GBN)', color='#e74c3c')
axes[0].bar(x + width/2, sr_retrans, width, label='Selective Repeat (SR)', color='#2ecc71')
axes[0].set_ylabel('Number of Retransmissions', fontsize=11, fontweight='bold')
axes[0].set_title('GBN vs SR: Packet Retransmissions (N=4, 200 Pkts)', fontsize=12, fontweight='bold')
axes[0].set_xticks(x)
axes[0].set_xticklabels(labels, fontsize=10)
axes[0].legend(fontsize=10)
axes[0].grid(axis='y', linestyle='--', alpha=0.7)

for i in range(len(labels)):
    axes[0].text(x[i] - width/2, gbn_retrans[i] + max(gbn_retrans)*0.015 + 0.5, str(gbn_retrans[i]), ha='center', fontsize=9, fontweight='bold')
    axes[0].text(x[i] + width/2, sr_retrans[i] + max(gbn_retrans)*0.015 + 0.5, str(sr_retrans[i]), ha='center', fontsize=9, fontweight='bold')

# Plot 2: Throughput
gbn_tp = [r["gbn"]["throughput"] for r in results]
sr_tp = [r["sr"]["throughput"] for r in results]

axes[1].bar(x - width/2, gbn_tp, width, label='Go-Back-N (GBN)', color='#e74c3c')
axes[1].bar(x + width/2, sr_tp, width, label='Selective Repeat (SR)', color='#2ecc71')
axes[1].set_ylabel('Throughput (pkts/sec)', fontsize=11, fontweight='bold')
axes[1].set_title('GBN vs SR: Effective Throughput', fontsize=12, fontweight='bold')
axes[1].set_xticks(x)
axes[1].set_xticklabels(labels, fontsize=10)
axes[1].legend(fontsize=10)
axes[1].grid(axis='y', linestyle='--', alpha=0.7)

for i in range(len(labels)):
    axes[1].text(x[i] - width/2, gbn_tp[i] + 0.05, f"{gbn_tp[i]:.2f}", ha='center', fontsize=9, fontweight='bold')
    axes[1].text(x[i] + width/2, sr_tp[i] + 0.05, f"{sr_tp[i]:.2f}", ha='center', fontsize=9, fontweight='bold')

import os
out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'gbn_vs_sr_comparison.png')
plt.savefig(out_path, dpi=300)
print(f"\nGraph saved successfully to '{out_path}'")

