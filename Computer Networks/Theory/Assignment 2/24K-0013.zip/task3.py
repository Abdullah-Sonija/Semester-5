"""
Reliable Transport Protocols Simulation: Go-Back-N (GBN) & Selective Repeat (SR)
Disaster-Response Satellite Network Simulation
Roll Number: 24k-0013
Seed: 0013
"""

import sys
import random
import heapq
import argparse

# ----------------- Packet & Checksum -----------------

def calculate_checksum(seqnum: int, acknum: int, payload: str) -> int:
    """Computes a simple 16-bit internet-style checksum over seqnum, acknum, and payload bytes."""
    data = f"{seqnum}:{acknum}:{payload}".encode('utf-8')
    checksum = 0
    for byte in data:
        checksum = (checksum + byte) & 0xFFFF
    return checksum

class Packet:
    def __init__(self, seqnum: int, acknum: int, payload: str, checksum: int = None):
        self.seqnum = seqnum
        self.acknum = acknum
        self.payload = payload
        if checksum is None:
            self.checksum = calculate_checksum(seqnum, acknum, payload)
        else:
            self.checksum = checksum

    def is_corrupted(self) -> bool:
        return self.checksum != calculate_checksum(self.seqnum, self.acknum, self.payload)

    def corrupt(self):
        # Invert checksum to simulate corruption
        self.checksum = (self.checksum ^ 0xFFFF) & 0xFFFF

    def __repr__(self):
        return f"Packet(seq={self.seqnum}, ack={self.acknum}, payload='{self.payload}')"

# ----------------- Discrete Event Simulation Engine -----------------

class Event:
    def __init__(self, event_time: float, event_type: str, handler, priority: int = 0, event_id: int = 0):
        self.event_time = event_time
        self.event_type = event_type
        self.handler = handler
        self.priority = priority
        self.event_id = event_id
        self.cancelled = False

    def cancel(self):
        self.cancelled = True

    def __lt__(self, other):
        if self.event_time == other.event_time:
            if self.priority == other.priority:
                return self.event_id < other.event_id
            return self.priority < other.priority
        return self.event_time < other.event_time

class SimulationEnvironment:
    def __init__(self, seed: int = 13):
        self.current_time = 0.0
        self.event_queue = []
        self._counter = 0
        random.seed(seed)

    def schedule(self, delay: float, event_type: str, handler, priority: int = 0):
        self._counter += 1
        evt = Event(self.current_time + delay, event_type, handler, priority, self._counter)
        heapq.heappush(self.event_queue, evt)
        return evt


    def run(self, max_time: float = 10000.0):
        while self.event_queue:
            evt = heapq.heappop(self.event_queue)
            self.current_time = evt.event_time
            if self.current_time > max_time:
                break
            if not evt.cancelled:
                evt.handler()


# ----------------- Simulated Unreliable Channel -----------------

class Channel:
    def __init__(self, env: SimulationEnvironment, loss_prob: float, corrupt_prob: float, delay_prob: float, 
                 base_delay: float = 0.25, max_delay: float = 0.75):
        self.env = env
        self.loss_prob = loss_prob
        self.corrupt_prob = corrupt_prob
        self.delay_prob = delay_prob
        self.base_delay = base_delay  # Default one-way delay for satellite link
        self.max_delay = max_delay

    def transmit(self, packet: Packet, destination_callback, entity_name: str):
        is_ack = (packet.payload == "ACK")
        pkt_desc = f"ACK {packet.acknum}" if is_ack else f"PKT {packet.seqnum}"

        # 1. Packet Loss check
        if random.random() < self.loss_prob:
            print(f"[{self.env.current_time:8.3f}s] [CHANNEL] [LOSS] {pkt_desc} was LOST in channel")
            return

        # Create a deep copy for transmission
        pkt_copy = Packet(packet.seqnum, packet.acknum, packet.payload, packet.checksum)
        if hasattr(packet, 'abs_acknum'):
            pkt_copy.abs_acknum = packet.abs_acknum


        # 2. Corruption check
        if random.random() < self.corrupt_prob:
            pkt_copy.corrupt()
            print(f"[{self.env.current_time:8.3f}s] [CHANNEL] [CORRUPT] {pkt_desc} was CORRUPTED")

        # 3. Transmission Delay calculation
        delay = self.base_delay
        if random.random() < self.delay_prob:
            extra_delay = random.uniform(0.1, self.max_delay)
            delay += extra_delay
            print(f"[{self.env.current_time:8.3f}s] [CHANNEL] [DELAY] {pkt_desc} delayed by extra {extra_delay:.3f}s (total: {delay:.3f}s)")

        self.env.schedule(delay, f"Deliver_{pkt_desc}", lambda: destination_callback(pkt_copy))

# ----------------- Go-Back-N Protocol -----------------

class GBNSender:
    def __init__(self, env: SimulationEnvironment, channel: Channel, total_packets: int, N: int, k: int, timeout: float):
        self.env = env
        self.channel = channel
        self.total_packets = total_packets
        self.N = N
        self.k = k
        self.seq_mod = 1 << k
        self.timeout = timeout

        # GBN Slide terminology
        self.base = 0         # absolute packet index of oldest unACKed packet
        self.nextseqnum = 0   # absolute packet index of next packet to send
        self.timer_event = None
        self.timer_start_time = 0.0

        # Stats
        self.packets_transmitted = 0
        self.retransmissions = 0
        self.receiver = None

    def map_seq(self, abs_idx: int) -> int:
        return abs_idx % self.seq_mod

    def start_timer(self):
        if self.timer_event is not None:
            self.timer_event.cancel()
        self.timer_start_time = self.env.current_time
        self.timer_event = self.env.schedule(self.timeout, "GBN_Timeout", self.handle_timeout)

    def stop_timer(self):
        if self.timer_event is not None:
            self.timer_event.cancel()
        self.timer_event = None


    def send_packets(self):
        while self.nextseqnum < self.base + self.N and self.nextseqnum < self.total_packets:
            seq = self.map_seq(self.nextseqnum)
            payload = f"Data_{self.nextseqnum}"
            pkt = Packet(seq, -1, payload)
            print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [SEND] Sending pkt {seq} (abs {self.nextseqnum}) | Window: [{self.map_seq(self.base)}..{self.map_seq(min(self.base + self.N - 1, self.total_packets - 1))}]")
            self.packets_transmitted += 1

            if self.base == self.nextseqnum:
                self.start_timer()

            self.channel.transmit(pkt, self.receiver.receive_packet, "Receiver")
            self.nextseqnum += 1

    def receive_ack(self, ack_pkt: Packet):
        if ack_pkt.is_corrupted():
            print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [CORRUPT] Corrupted ACK received! Ignored.")
            return

        ack_seq = ack_pkt.acknum
        print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [RCV-ACK] Received cumulative ACK {ack_seq}")

        # In GBN with sequence wrap-around modulo 2^k and channel delay,
        # an old delayed ACK from a previous wrap cycle can arrive.
        # We verify that ack_seq matches a packet in the current in-flight window [base .. nextseqnum - 1]
        # and that the ACK's full sequence index is >= base (i.e. strictly forward progress).
        # When an ACK is sent by the receiver, ack_pkt.seqnum carries the full un-modulo packet index if present,
        # or we verify that the ACK strictly moves base forward without skipping unacknowledged packets.
        if hasattr(ack_pkt, 'abs_acknum') and ack_pkt.abs_acknum is not None:
            if ack_pkt.abs_acknum >= self.base:
                self.base = ack_pkt.abs_acknum + 1
                print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [SLIDE] Window base advanced to abs {self.base} (seq {self.map_seq(self.base)})")
                if self.base == self.nextseqnum:
                    self.stop_timer()
                else:
                    self.start_timer()
                self.send_packets()
            else:
                print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [DUP-ACK] Stale delayed ACK {ack_seq} (abs {ack_pkt.abs_acknum} < base {self.base}) ignored.")
            return

        # Fallback for pure modulo sequence numbers
        dist = (ack_seq - self.map_seq(self.base)) % self.seq_mod
        if dist < (self.nextseqnum - self.base):
            self.base = self.base + dist + 1
            print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [SLIDE] Window base advanced to abs {self.base} (seq {self.map_seq(self.base)})")
            if self.base == self.nextseqnum:
                self.stop_timer()
            else:
                self.start_timer()
            self.send_packets()
        else:
            print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [DUP-ACK] Stale/delayed ACK {ack_seq} ignored.")





    def handle_timeout(self):
        # Check if timer is still valid
        if self.timer_event is None or self.base == self.nextseqnum:
            return

        print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [TIMEOUT] Timeout expired for base {self.map_seq(self.base)} (abs {self.base})! Retransmitting window.")
        self.start_timer()
        # Resend all unACKed packets from base to nextseqnum - 1
        for idx in range(self.base, self.nextseqnum):
            seq = self.map_seq(idx)
            payload = f"Data_{idx}"
            pkt = Packet(seq, -1, payload)
            print(f"[{self.env.current_time:8.3f}s] [SENDER-GBN] [RETRANS] Resending pkt {seq} (abs {idx})")
            self.packets_transmitted += 1
            self.retransmissions += 1
            self.channel.transmit(pkt, self.receiver.receive_packet, "Receiver")

class GBNReceiver:
    def __init__(self, env: SimulationEnvironment, channel: Channel, total_packets: int, k: int):
        self.env = env
        self.channel = channel
        self.total_packets = total_packets
        self.k = k
        self.seq_mod = 1 << k

        # GBN Slide terminology
        self.expectedseqnum = 0  # absolute index
        self.last_ack_sent = -1
        self.packets_delivered = 0
        self.sender = None

    def map_seq(self, abs_idx: int) -> int:
        return abs_idx % self.seq_mod

    def receive_packet(self, pkt: Packet):
        if pkt.is_corrupted():
            print(f"[{self.env.current_time:8.3f}s] [RCVR-GBN] [CORRUPT] Corrupted packet received! Discarded.")
            # Re-send ACK for last correctly received packet
            if self.last_ack_sent != -1:
                ack_pkt = Packet(-1, self.last_ack_sent, "ACK")
                print(f"[{self.env.current_time:8.3f}s] [RCVR-GBN] [RE-ACK] Resending ACK {self.last_ack_sent}")
                self.channel.transmit(ack_pkt, self.sender.receive_ack, "Sender")
            return

        expected_seq = self.map_seq(self.expectedseqnum)
        if pkt.seqnum == expected_seq:
            print(f"[{self.env.current_time:8.3f}s] [RCVR-GBN] [ACCEPT] In-order pkt {pkt.seqnum} accepted & delivered. expectedseqnum -> {self.map_seq(self.expectedseqnum + 1)}")
            self.packets_delivered += 1
            self.last_ack_sent = pkt.seqnum
            self.last_abs_ack = self.expectedseqnum
            self.expectedseqnum += 1
            ack_pkt = Packet(-1, pkt.seqnum, "ACK")
            ack_pkt.abs_acknum = self.last_abs_ack
            self.channel.transmit(ack_pkt, self.sender.receive_ack, "Sender")
        else:
            print(f"[{self.env.current_time:8.3f}s] [RCVR-GBN] [DISCARD] Out-of-order pkt {pkt.seqnum} (expected {expected_seq}) DISCARDED!")
            if self.last_ack_sent != -1:
                ack_pkt = Packet(-1, self.last_ack_sent, "ACK")
                ack_pkt.abs_acknum = self.last_abs_ack
                print(f"[{self.env.current_time:8.3f}s] [RCVR-GBN] [RE-ACK] Resending cumulative ACK {self.last_ack_sent}")
                self.channel.transmit(ack_pkt, self.sender.receive_ack, "Sender")


# ----------------- Selective Repeat Protocol -----------------

class SRSender:
    def __init__(self, env: SimulationEnvironment, channel: Channel, total_packets: int, N: int, k: int, timeout: float):
        self.env = env
        self.channel = channel
        self.total_packets = total_packets
        self.N = N
        self.k = k
        self.seq_mod = 1 << k
        self.timeout = timeout

        # SR Slide terminology
        self.send_base = 0
        self.nextseqnum = 0
        self.acked = {}           # abs_idx -> bool
        self.timers = {}          # abs_idx -> Event
        self.packets_transmitted = 0
        self.retransmissions = 0
        self.receiver = None

    def map_seq(self, abs_idx: int) -> int:
        return abs_idx % self.seq_mod

    def start_timer(self, abs_idx: int):
        if abs_idx in self.timers and self.timers[abs_idx] is not None:
            self.timers[abs_idx].cancel()
        self.timers[abs_idx] = self.env.schedule(self.timeout, f"SR_Timeout_{abs_idx}", lambda idx=abs_idx: self.handle_timeout(idx))

    def stop_timer(self, abs_idx: int):
        if abs_idx in self.timers and self.timers[abs_idx] is not None:
            self.timers[abs_idx].cancel()
            self.timers[abs_idx] = None


    def send_packets(self):
        while self.nextseqnum < self.send_base + self.N and self.nextseqnum < self.total_packets:
            seq = self.map_seq(self.nextseqnum)
            payload = f"Data_{self.nextseqnum}"
            pkt = Packet(seq, -1, payload)
            print(f"[{self.env.current_time:8.3f}s] [SENDER-SR] [SEND] Sending pkt {seq} (abs {self.nextseqnum}) | Window: [{self.map_seq(self.send_base)}..{self.map_seq(min(self.send_base + self.N - 1, self.total_packets - 1))}]")
            self.packets_transmitted += 1
            self.acked[self.nextseqnum] = False
            self.start_timer(self.nextseqnum)
            self.channel.transmit(pkt, self.receiver.receive_packet, "Receiver")
            self.nextseqnum += 1

    def receive_ack(self, ack_pkt: Packet):
        if ack_pkt.is_corrupted():
            print(f"[{self.env.current_time:8.3f}s] [SENDER-SR] [CORRUPT] Corrupted ACK received! Ignored.")
            return

        ack_seq = ack_pkt.acknum
        print(f"[{self.env.current_time:8.3f}s] [SENDER-SR] [RCV-ACK] Received individual ACK {ack_seq}")

        # Find matching packet in window [send_base .. send_base + N - 1]
        for idx in range(self.send_base, min(self.send_base + self.N, self.total_packets)):
            if self.map_seq(idx) == ack_seq and not self.acked.get(idx, False):
                self.acked[idx] = True
                self.stop_timer(idx)
                print(f"[{self.env.current_time:8.3f}s] [SENDER-SR] [ACKED] Packet {ack_seq} (abs {idx}) marked ACKed")

                # If this ACK is for send_base, advance window base
                if idx == self.send_base:
                    while self.send_base < self.total_packets and self.acked.get(self.send_base, False):
                        self.send_base += 1
                    print(f"[{self.env.current_time:8.3f}s] [SENDER-SR] [SLIDE] send_base advanced to abs {self.send_base} (seq {self.map_seq(self.send_base)})")
                    self.send_packets()
                break

    def handle_timeout(self, abs_idx: int):
        if self.timers.get(abs_idx) is None or self.acked.get(abs_idx, False):
            return

        seq = self.map_seq(abs_idx)
        print(f"[{self.env.current_time:8.3f}s] [SENDER-SR] [TIMEOUT] Timeout expired for individual pkt {seq} (abs {abs_idx})! Retransmitting ONLY pkt {seq}")
        self.packets_transmitted += 1
        self.retransmissions += 1
        self.start_timer(abs_idx)
        pkt = Packet(seq, -1, f"Data_{abs_idx}")
        self.channel.transmit(pkt, self.receiver.receive_packet, "Receiver")

class SRReceiver:
    def __init__(self, env: SimulationEnvironment, channel: Channel, total_packets: int, N: int, k: int):
        self.env = env
        self.channel = channel
        self.total_packets = total_packets
        self.N = N
        self.k = k
        self.seq_mod = 1 << k

        # SR Slide terminology
        self.rcv_base = 0
        self.buffer = {}  # abs_idx -> Packet
        self.packets_delivered = 0
        self.sender = None

    def map_seq(self, abs_idx: int) -> int:
        return abs_idx % self.seq_mod

    def receive_packet(self, pkt: Packet):
        if pkt.is_corrupted():
            print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [CORRUPT] Corrupted packet received! Discarded.")
            return

        # Check if received packet falls within current receiver window [rcv_base .. rcv_base + N - 1]
        matched_abs = None
        for idx in range(self.rcv_base, min(self.rcv_base + self.N, self.total_packets)):
            if self.map_seq(idx) == pkt.seqnum:
                matched_abs = idx
                break

        if matched_abs is not None:
            # Send individual ACK
            ack_pkt = Packet(-1, pkt.seqnum, "ACK")
            print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [ACK] Sending ACK {pkt.seqnum} for pkt in window")
            self.channel.transmit(ack_pkt, self.sender.receive_ack, "Sender")

            # Buffer or deliver
            self.buffer[matched_abs] = pkt
            print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [BUFFER] Buffered pkt {pkt.seqnum} (abs {matched_abs})")

            # If pkt matches rcv_base, advance window and deliver contiguous buffered packets
            if matched_abs == self.rcv_base:
                while self.rcv_base in self.buffer:
                    delivered_pkt = self.buffer.pop(self.rcv_base)
                    self.packets_delivered += 1
                    print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [DELIVER] Delivering in-order pkt {delivered_pkt.seqnum} (abs {self.rcv_base}) to upper layer")
                    self.rcv_base += 1
                print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [SLIDE] rcv_base advanced to abs {self.rcv_base} (seq {self.map_seq(self.rcv_base)})")

        # Check if received packet falls within [rcv_base - N .. rcv_base - 1] (previously ACKed)
        else:
            prev_match = None
            for idx in range(max(0, self.rcv_base - self.N), self.rcv_base):
                if self.map_seq(idx) == pkt.seqnum:
                    prev_match = idx
                    break
            if prev_match is not None:
                # Must re-ACK previously received packet so sender can advance its window
                ack_pkt = Packet(-1, pkt.seqnum, "ACK")
                print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [RE-ACK] Re-acknowledging already received pkt {pkt.seqnum} (abs {prev_match})")
                self.channel.transmit(ack_pkt, self.sender.receive_ack, "Sender")
            else:
                print(f"[{self.env.current_time:8.3f}s] [RCVR-SR] [OUT-OF-WINDOW] Pkt {pkt.seqnum} outside valid receiver window! Ignored.")

# ----------------- Main Simulation Runner -----------------

def run_simulation(protocol: str, num_packets: int, N: int, k: int, 
                   loss_prob: float, corrupt_prob: float, delay_prob: float, 
                   timeout: float, seed: int = 13):
    print("=" * 70)
    print(f"STARTING SIMULATION: Protocol={protocol.upper()}, Packets={num_packets}, N={N}, k={k} (mod {1<<k})")
    print(f"Loss={loss_prob}, Corrupt={corrupt_prob}, Delay={delay_prob}, Timeout={timeout}s, Seed={seed}")
    print("=" * 70)

    env = SimulationEnvironment(seed=seed)
    channel = Channel(env, loss_prob, corrupt_prob, delay_prob)

    if protocol.lower() == "gbn":
        sender = GBNSender(env, channel, num_packets, N, k, timeout)
        receiver = GBNReceiver(env, channel, num_packets, k)
    elif protocol.lower() == "sr":
        sender = SRSender(env, channel, num_packets, N, k, timeout)
        receiver = SRReceiver(env, channel, num_packets, N, k)
    else:
        raise ValueError(f"Unknown protocol: {protocol}")

    sender.receiver = receiver
    receiver.sender = sender

    # Kick off transmission
    sender.send_packets()
    env.run()

    print("=" * 70)
    print(f"SIMULATION FINISHED at t = {env.current_time:.3f}s")
    print(f"Total Packets Transmitted : {sender.packets_transmitted}")
    print(f"Total Retransmissions     : {sender.retransmissions}")
    print(f"Packets Delivered In-Order: {receiver.packets_delivered}/{num_packets}")
    throughput = (receiver.packets_delivered / env.current_time) if env.current_time > 0 else 0
    print(f"Effective Throughput      : {throughput:.3f} pkts/sec")
    print("=" * 70)

    return {
        "time": env.current_time,
        "transmitted": sender.packets_transmitted,
        "retransmissions": sender.retransmissions,
        "delivered": receiver.packets_delivered,
        "throughput": throughput
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reliable Transport Protocol Simulator (GBN & SR)")
    parser.add_argument("--protocol", choices=["gbn", "sr"], default="gbn", help="Protocol to simulate")
    parser.add_argument("--num_packets", type=int, default=10, help="Total number of packets to send")
    parser.add_argument("--window_size", "-N", type=int, default=4, help="Window size N")
    parser.add_argument("--k_bits", "-k", type=int, default=3, help="Sequence number bits (mod 2^k)")
    parser.add_argument("--loss", type=float, default=0.0, help="Packet/ACK loss probability")
    parser.add_argument("--corrupt", type=float, default=0.0, help="Corruption probability")
    parser.add_argument("--delay", type=float, default=0.0, help="Extra delay probability")
    parser.add_argument("--timeout", type=float, default=1.0, help="Timeout in seconds")
    parser.add_argument("--seed", type=int, default=13, help="Random seed (last 4 digits of roll no: 0013 -> 13)")

    args = parser.parse_args()
    run_simulation(
        protocol=args.protocol,
        num_packets=args.num_packets,
        N=args.window_size,
        k=args.k_bits,
        loss_prob=args.loss,
        corrupt_prob=args.corrupt,
        delay_prob=args.delay,
        timeout=args.timeout,
        seed=args.seed
    )
