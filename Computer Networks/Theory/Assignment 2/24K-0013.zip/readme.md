#### CLI Usage & Sample Commands
```bash
python task3.py --protocol gbn --num_packets 10 -N 4 -k 3 --loss 0.1 --seed 13

python task3.py --protocol sr --num_packets 10 -N 4 -k 3 --loss 0.1 --seed 13

python task3.py --protocol sr --num_packets 200 -N 4 -k 3 --loss 0.05 --corrupt 0.05 --delay 0.10 --seed 13

python task4.py
```